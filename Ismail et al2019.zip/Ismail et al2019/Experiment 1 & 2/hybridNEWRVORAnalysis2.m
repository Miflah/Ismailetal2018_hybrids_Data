function P_est = hybridNEWRVORAnalysis2(files,ci_true)

%Author: AM (modified on 06/03/2018)

%fitting a cumulative normal function

%'T' -> thresholds (half-way point/point of inflection of unscaled sigmoid)
%'S' -> slope
%sigmoid); for weibull fit estimates, get the log10(S)
%'CIL' -. lower bounds of confidence intervals for threshold
%'CIU' -. upper bounds of confidence intervals for threshold

% warning off
num_files = length(files);

resp = [];

for i = 1 : num_files
    
    cur_file = files{i};
    resp_m = (cur_file.data);
    resp = [resp ; resp_m];
end


LR_list = [-3.66,-2.20,-1.39,-0.41,-0.20,0,0.20,0.41,1.39,2.20,3.66];
R_list = exp(LR_list);

repeats = 10;

anim_resp = 97;
ina_resp = 98;

anim_cats = [1 2];
ina_cats = [3 4];



    %obtain data for conditions in which the animal was cardinally filtered
    %and the cardinal component was chosen as dominant
    for i = 1 : numel(anim_cats)
        
        cur_anim = anim_cats(i);
        
        for j =  1: numel(ina_cats)
            
            cur_ina = ina_cats(j);
            
            for k = 1: numel(R_list)
                
                cur_R = R_list(k);
                
                choice_card1(i,j,k) = arrayfun(@(y)length(resp(resp(:,9)==y ...
                    & resp(:,2)== cur_anim & resp(:,3)== cur_ina & ...
                    resp(:,4)== cur_R & resp(:,5)== 0)), anim_resp);      
                
                
            end       
            
        end
    end
    
    
    %obtain data for conditions in which the animal was inter-cardinally filtered
    %and the cardinal component was chosen as dominant
    for i = 1 : numel(anim_cats)
        
        cur_anim = anim_cats(i);
        
        for j =  1: numel(ina_cats)
            
            cur_ina = ina_cats(j);
            
            for k = 1: numel(R_list)
                
                cur_R = R_list(k);
                
                choice_card2(i,j,k) = arrayfun(@(y)length(resp(resp(:,9)==y ...
                    & resp(:,2)== cur_anim & resp(:,3)== cur_ina & ...
                    resp(:,4)== cur_R & resp(:,5)== 45)), ina_resp);      
                
                
            end       
            
        end
    end
    
    
    %plot data for cardinal animal
    matC_resp_BA_BI(:,1) = LR_list(:);
    matC_resp_BA_BI(:,2) = choice_card1(1,1,:);
    matC_resp_BA_BI(:,3) = repeats;
    
    matC_resp_BA_SI(:,1) = LR_list(:);
    matC_resp_BA_SI(:,2) = choice_card1(1,2,:);
    matC_resp_BA_SI(:,3) = repeats;
    
    matC_resp_SA_BI(:,1) = LR_list(:);
    matC_resp_SA_BI(:,2) = choice_card1(2,1,:);
    matC_resp_SA_BI(:,3) = repeats;
    
    matC_resp_SA_SI(:,1) = LR_list(:);
    matC_resp_SA_SI(:,2) = choice_card1(2,2,:);
    matC_resp_SA_SI(:,3) = repeats;
    
    
    %plot data for cardinal animal
    matI_resp_BA_BI(:,1) = LR_list(:);
    matI_resp_BA_BI(:,2) = choice_card2(1,1,:);
    matI_resp_BA_BI(:,3) = repeats;
    
    matI_resp_BA_SI(:,1) = LR_list(:);
    matI_resp_BA_SI(:,2) = choice_card2(1,2,:);
    matI_resp_BA_SI(:,3) = repeats;
    
    matI_resp_SA_BI(:,1) = LR_list(:);
    matI_resp_SA_BI(:,2) = choice_card2(2,1,:);
    matI_resp_SA_BI(:,3) = repeats;
    
    matI_resp_SA_SI(:,1) = LR_list(:);
    matI_resp_SA_SI(:,2) = choice_card2(2,2,:);
    matI_resp_SA_SI(:,3) = repeats;
    
    
    %plot data categorically
    mat_resp_BA_BI(:,1) = LR_list(:);
    mat_resp_BA_BI(:,2) = matC_resp_BA_BI(:,2) + (repeats - flipud(matI_resp_BA_BI(:,2)));
    mat_resp_BA_BI(:,3) = repeats*2;
    
    mat_resp_BA_SI(:,1) = LR_list(:);
    mat_resp_BA_SI(:,2) = matC_resp_BA_SI(:,2) + (repeats - flipud(matI_resp_BA_SI(:,2)));
    mat_resp_BA_SI(:,3) = repeats*2;
    
    mat_resp_SA_BI(:,1) = LR_list(:);
    mat_resp_SA_BI(:,2) = matC_resp_SA_BI(:,2) + (repeats - flipud(matI_resp_SA_BI(:,2)));
    mat_resp_SA_BI(:,3) = repeats*2;
    
    mat_resp_SA_SI(:,1) = LR_list(:);
    mat_resp_SA_SI(:,2) = matC_resp_SA_SI(:,2) + (repeats - flipud(matI_resp_SA_SI(:,2)));
    mat_resp_SA_SI(:,3) = repeats*2;
    
    
    %psychometric function presets
    options = struct;
    options.sigmoidName = 'norm';
    options.expType = 'YesNo';       
    options.fixedPars = [NaN; NaN; NaN; NaN; NaN];
    
    
    %%%%
    optionsC = struct;
    optionsC.sigmoidName = 'norm';
    optionsC.expType = 'YesNo';       
    optionsC.fixedPars = [0; NaN; NaN; NaN; NaN];
    
    %%%
    optionsB = struct;
    optionsB.sigmoidName = 'norm';
    optionsB.expType = 'YesNo';
    
    %cardinal animal results
    result_C_BA_BI = psignifit(matC_resp_BA_BI, options);
    result_C_BA_BI_C = psignifit(matC_resp_BA_BI, optionsC);
    T(1,1) = result_C_BA_BI.Fit(1); S(1,1) = result_C_BA_BI.Fit(2);
    SC(1,1) = result_C_BA_BI_C.Fit(2); L(1,1) = result_C_BA_BI.Fit(3);
    G(1,1) = result_C_BA_BI.Fit(4);
    LL_C_BABI = NLLpsignifit(matC_resp_BA_BI, optionsB, result_C_BA_BI.Fit);
    LL_C_BABI_C = NLLpsignifit(matC_resp_BA_BI, optionsB, result_C_BA_BI_C.Fit);
    pval(1,1) = 1 - cdf('ChiSquare', 2 * ((-LL_C_BABI_C) - (-LL_C_BABI)), 1);
    
    if nargin == 2
        [CI_L(1,1), CI_U(1,1)] = NonPBootPsignPALMix(matC_resp_BA_BI, options, T(1,1), 95);
    end
    
    result_C_BA_SI = psignifit(matC_resp_BA_SI, options);
    result_C_BA_SI_C = psignifit(matC_resp_BA_SI, optionsC);
    T(2,1) = result_C_BA_SI.Fit(1); S(2,1) = result_C_BA_SI.Fit(2);
    SC(2,1) = result_C_BA_SI_C.Fit(2); L(2,1) = result_C_BA_SI.Fit(3);
    G(2,1) = result_C_BA_SI.Fit(4);
    LL_C_BASI = NLLpsignifit(matC_resp_BA_SI, optionsB, result_C_BA_SI.Fit);
    LL_C_BASI_C = NLLpsignifit(matC_resp_BA_SI, optionsB, result_C_BA_SI_C.Fit);
    pval(2,1) = 1 - cdf('ChiSquare', 2 * ((-LL_C_BASI_C) - (-LL_C_BASI)), 1);
    
    if nargin == 2
        [CI_L(2,1), CI_U(2,1)] = NonPBootPsignPALMix(matC_resp_BA_SI, options, T(2,1), 95);
    end
    
    result_C_SA_BI = psignifit(matC_resp_SA_BI, options);
    result_C_SA_BI_C = psignifit(matC_resp_SA_BI, optionsC);
    T(3,1) = result_C_SA_BI.Fit(1); S(3,1) = result_C_SA_BI.Fit(2);
    SC(3,1) = result_C_SA_BI_C.Fit(2); L(3,1) = result_C_SA_BI.Fit(3);
    G(3,1) = result_C_SA_BI.Fit(4);
    LL_C_SABI = NLLpsignifit(matC_resp_SA_BI, optionsB, result_C_SA_BI.Fit);
    LL_C_SABI_C = NLLpsignifit(matC_resp_SA_BI, optionsB, result_C_SA_BI_C.Fit);
    pval(3,1) = 1 - cdf('ChiSquare', 2 * ((-LL_C_SABI_C) - (-LL_C_SABI)), 1);
    
    if nargin == 2
        [CI_L(3,1), CI_U(3,1)] = NonPBootPsignPALMix(matC_resp_SA_BI, options, T(3,1), 95);
    end
    
    result_C_SA_SI = psignifit(matC_resp_SA_SI, options);
    result_C_SA_SI_C = psignifit(matC_resp_SA_SI, optionsC);
    T(4,1) = result_C_SA_SI.Fit(1); S(4,1) = result_C_SA_SI.Fit(2);
    SC(4,1) = result_C_SA_SI_C.Fit(2); L(4,1) = result_C_SA_SI.Fit(3);
    G(4,1) = result_C_SA_SI.Fit(4);
    LL_C_SASI = NLLpsignifit(matC_resp_SA_SI, optionsB, result_C_SA_SI.Fit);
    LL_C_SASI_C = NLLpsignifit(matC_resp_SA_SI, optionsB, result_C_SA_SI_C.Fit);
    pval(4,1) = 1 - cdf('ChiSquare', 2 * ((-LL_C_SASI_C) - (-LL_C_SASI)), 1);
    
    if nargin == 2
        [CI_L(4,1), CI_U(4,1)] = NonPBootPsignPALMix(matC_resp_SA_SI, options, T(4,1), 95);
    end
    
           
    
    %intercardinal animal results
    result_I_BA_BI = psignifit(matI_resp_BA_BI, options);
    result_I_BA_BI_C = psignifit(matI_resp_BA_BI, optionsC);
    T(5,1) = result_I_BA_BI.Fit(1); S(5,1) = result_I_BA_BI.Fit(2);
    SC(5,1) = result_I_BA_BI_C.Fit(2); L(5,1) = result_I_BA_BI.Fit(3);
    G(5,1) = result_I_BA_BI.Fit(4);
    LL_I_BABI = NLLpsignifit(matI_resp_BA_BI, optionsB, result_I_BA_BI.Fit);
    LL_I_BABI_C = NLLpsignifit(matI_resp_BA_BI, optionsB, result_I_BA_BI_C.Fit);
    pval(5,1) = 1 - cdf('ChiSquare', 2 * ((-LL_I_BABI_C) - (-LL_I_BABI)), 1);
    
    if nargin == 2
        [CI_L(5,1), CI_U(5,1)] = NonPBootPsignPALMix(matI_resp_BA_BI, options, T(5,1), 95);
    end
    
    result_I_BA_SI = psignifit(matI_resp_BA_SI, options);
    result_I_BA_SI_C = psignifit(matI_resp_BA_SI, optionsC);
    T(6,1) = result_I_BA_SI.Fit(1); S(6,1) = result_I_BA_SI.Fit(2);
    SC(6,1) = result_I_BA_SI_C.Fit(2); L(6,1) = result_I_BA_SI.Fit(3);
    G(6,1) = result_I_BA_SI.Fit(4);
    LL_I_BASI = NLLpsignifit(matI_resp_BA_SI, optionsB, result_I_BA_SI.Fit);
    LL_I_BASI_C = NLLpsignifit(matI_resp_BA_SI, optionsB, result_I_BA_SI_C.Fit);
    pval(6,1) = 1 - cdf('ChiSquare', 2 * ((-LL_I_BASI_C) - (-LL_I_BASI)), 1);
    
    if nargin == 2
        [CI_L(6,1), CI_U(6,1)] = NonPBootPsignPALMix(matI_resp_BA_SI, options, T(6,1), 95);
    end
    
    result_I_SA_BI = psignifit(matI_resp_SA_BI, options);
    result_I_SA_BI_C = psignifit(matI_resp_SA_BI, optionsC);
    T(7,1) = result_I_SA_BI.Fit(1); S(7,1) = result_I_SA_BI.Fit(2);
    SC(7,1) = result_I_SA_BI_C.Fit(2); L(7,1) = result_I_SA_BI.Fit(3);
    G(7,1) = result_I_SA_BI.Fit(4);
    LL_I_SABI = NLLpsignifit(matI_resp_SA_BI, optionsB, result_I_SA_BI.Fit);
    LL_I_SABI_C = NLLpsignifit(matI_resp_SA_BI, optionsB, result_I_SA_BI_C.Fit);
    pval(7,1) = 1 - cdf('ChiSquare', 2 * ((-LL_I_SABI_C) - (-LL_I_SABI)), 1);
    
    if nargin == 2
        [CI_L(7,1), CI_U(7,1)] = NonPBootPsignPALMix(matI_resp_SA_BI, options, T(7,1), 95);
    end
    
    result_I_SA_SI = psignifit(matI_resp_SA_SI, options);
    result_I_SA_SI_C = psignifit(matI_resp_SA_SI, optionsC);
    T(8,1) = result_I_SA_SI.Fit(1); S(8,1) = result_I_SA_SI.Fit(2);
    SC(8,1) = result_I_SA_SI_C.Fit(2); L(8,1) = result_I_SA_SI.Fit(3);
    G(8,1) = result_I_SA_SI.Fit(4);
    LL_I_SASI = NLLpsignifit(matI_resp_SA_SI, optionsB, result_I_SA_SI.Fit);
    LL_I_SASI_C = NLLpsignifit(matI_resp_SA_SI, optionsB, result_I_SA_SI_C.Fit);
    pval(8,1) = 1 - cdf('ChiSquare', 2 * ((-LL_I_SASI_C) - (-LL_I_SASI)), 1);
    
    if nargin == 2
        [CI_L(8,1), CI_U(8,1)] = NonPBootPsignPALMix(matI_resp_SA_SI, options, T(8,1), 95);
    end
    
    
    %categorical results
    result_BA_BI = psignifit(mat_resp_BA_BI, options);
    result_BA_BI_C = psignifit(mat_resp_BA_BI, optionsC);
    T(9,1) = result_BA_BI.Fit(1); S(9,1) = result_BA_BI.Fit(2);
    SC(9,1) = result_BA_BI_C.Fit(2); L(9,1) = result_BA_BI.Fit(3);
    G(9,1) = result_BA_BI.Fit(4);
    LL_BABI = NLLpsignifit(mat_resp_BA_BI, optionsB, result_BA_BI.Fit);
    LL_BABI_C = NLLpsignifit(mat_resp_BA_BI, optionsB, result_BA_BI_C.Fit);
    pval(9,1) = 1 - cdf('ChiSquare', 2 * ((-LL_BABI_C) - (-LL_BABI)), 1);
    
    if nargin == 2
        [CI_L(9,1), CI_U(9,1)] = NonPBootPsignPALMix(mat_resp_BA_BI, options, T(9,1), 95);
    end
    
    result_BA_SI = psignifit(mat_resp_BA_SI, options);
    result_BA_SI_C = psignifit(mat_resp_BA_SI, optionsC);
    T(10,1) = result_BA_SI.Fit(1); S(10,1) = result_BA_SI.Fit(2);
    SC(10,1) = result_BA_SI_C.Fit(2); L(10,1) = result_BA_SI.Fit(3);
    G(10,1) = result_BA_SI.Fit(4);
    LL_BASI = NLLpsignifit(mat_resp_BA_SI, optionsB, result_BA_SI.Fit);
    LL_BASI_C = NLLpsignifit(mat_resp_BA_SI, optionsB, result_BA_SI_C.Fit);
    pval(10,1) = 1 - cdf('ChiSquare', 2 * ((-LL_BASI_C) - (-LL_BASI)), 1);
    
    if nargin == 2
        [CI_L(10,1), CI_U(10,1)] = NonPBootPsignPALMix(mat_resp_BA_SI, options, T(10,1), 95);
    end
    
    result_SA_BI = psignifit(mat_resp_SA_BI, options);
    result_SA_BI_C = psignifit(mat_resp_SA_BI, optionsC);
    T(11,1) = result_SA_BI.Fit(1); S(11,1) = result_SA_BI.Fit(2);
    SC(11,1) = result_SA_BI_C.Fit(2); L(11,1) = result_SA_BI.Fit(3);
    G(11,1) = result_SA_BI.Fit(4);
    LL_SABI = NLLpsignifit(mat_resp_SA_BI, optionsB, result_SA_BI.Fit);
    LL_SABI_C = NLLpsignifit(mat_resp_SA_BI, optionsB, result_SA_BI_C.Fit);
    pval(11,1) = 1 - cdf('ChiSquare', 2 * ((-LL_SABI_C) - (-LL_SABI)), 1);
    
    if nargin == 2
        [CI_L(11,1), CI_U(11,1)] = NonPBootPsignPALMix(mat_resp_SA_BI, options, T(11,1), 95);
    end
    
    result_SA_SI = psignifit(mat_resp_SA_SI, options);
    result_SA_SI_C = psignifit(mat_resp_SA_SI, optionsC);
    T(12,1) = result_SA_SI.Fit(1); S(12,1) = result_SA_SI.Fit(2);
    SC(12,1) = result_SA_SI_C.Fit(2); L(12,1) = result_SA_SI.Fit(3);
    G(12,1) = result_SA_SI.Fit(4);
    LL_SASI = NLLpsignifit(mat_resp_SA_SI, optionsB, result_SA_SI.Fit);
    LL_SASI_C = NLLpsignifit(mat_resp_SA_SI, optionsB, result_SA_SI_C.Fit);
    pval(12,1) = 1 - cdf('ChiSquare', 2 * ((-LL_SASI_C) - (-LL_SASI)), 1);
    
    if nargin == 2
        [CI_L(12,1), CI_U(12,1)] = NonPBootPsignPALMix(mat_resp_SA_SI, options, T(12,1), 95);
    end
    
    
    %plot psyhometric fits
    plotOptions = struct;
    plotOptions.xLabel = 'Stimulus contrast (rms)';
    plotOptions.yLabel = 'Prop. choosing cardinal image';
    plotOptions.CIthresh = true;
    
    figure(1);
    subplot(241)
    plotPsych(result_C_BA_BI, plotOptions); title('SA-SI'); ylim([0 1]);
    subplot(242)
    plotPsych(result_C_BA_SI, plotOptions); title('SA-BI'); ylim([0 1]);
    subplot(243)
    plotPsych(result_C_SA_BI, plotOptions); title('BA_SI'); ylim([0 1]);
    subplot(244)
    plotPsych(result_C_SA_SI, plotOptions); title('BA-BI'); ylim([0 1]);
    
    subplot(245)
    plotPsych(result_I_BA_BI, plotOptions); title('SA-SI'); ylim([0 1]);
    subplot(246)
    plotPsych(result_I_BA_SI, plotOptions); title('SA-BI'); ylim([0 1]);
    subplot(247)
    plotPsych(result_I_SA_BI, plotOptions); title('BA_SI'); ylim([0 1]);
    subplot(248)
    plotPsych(result_I_SA_SI, plotOptions); title('BA-BI'); ylim([0 1]);
    
    
    figure(2);
    subplot(221)
    plotPsych(result_BA_BI, plotOptions); title('SA-SI'); ylim([0 1]);
    subplot(222)
    plotPsych(result_BA_SI, plotOptions); title('SA-BI'); ylim([0 1]);
    subplot(223)
    plotPsych(result_SA_BI, plotOptions); title('BA_SI'); ylim([0 1]);
    subplot(224)
    plotPsych(result_SA_SI, plotOptions); title('BA-BI'); ylim([0 1]);
    
    if nargin == 2
        P_est = [T, S, SC, L, G, pval, CI_L, CI_U];
    else        
        P_est = [T, S, SC, L, G, pval];
    end
       
    
%     warning on;
    
    
    
    
    
    
    
    
    




























    

