function P_est = hybridNEWAnalysis(files)

%Author: AM (modified on 03/01/2017)

%fitting a cumulative normal function

%'T' -> thresholds (half-way point/point of inflection of unscaled sigmoid)
%'S' -> slope
%sigmoid); for weibull fit estimates, get the log10(S)
%'CIL' -. lower bounds of confidence intervals for threshold
%'CIU' -. upper bounds of confidence intervals for threshold


warning off
num_files = length(files);

resp = [];

for i = 1 : num_files
    
    cur_file = files{i};
    resp_m = (cur_file.data);
    resp = [resp ; resp_m];
end


% No_list = [0,0.10,0.20];
% 
% 
% ratio_en = LR_list;
LR_list = [-3.66,-2.20,-1.39,-0.41,-0.20,0,0.20,0.41,1.39,2.20,3.66];
R_list = exp(LR_list);




%major component's category
m_c_cat = 1 : 4;


%keyboard reposnses given
kb_resp = [KbName('1'), KbName('2'), KbName('4'), KbName('5')];


%order of responses
Box_resp = [1 2 3 4];




    %initialise
    resp_an_c = zeros(numel(R_list),1); resp_fl_c = zeros(numel(R_list),1);
    resp_ho_c = zeros(numel(R_list),1); resp_ve_c = zeros(numel(R_list),1);
    
    resp_an_o = zeros(numel(R_list),1); resp_fl_o = zeros(numel(R_list),1);
    resp_ho_o = zeros(numel(R_list),1); resp_ve_o = zeros(numel(R_list),1);
    
    
    
    for i = 1 : length(R_list)
        
        CO_R = R_list(i);
        
        %proportion choosing the cardinal image when the major component is
        %cardinal and ....
        
        %an animal image        
        resp_an_c1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(1))), kb_resp(3));
        
        resp_an_c2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(2))), kb_resp(4));
        
        resp_an_c3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(3))), kb_resp(1));
        
        resp_an_c4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(4))), kb_resp(2));
        
        resp_an_c(i) = resp_an_c1 + resp_an_c2 + resp_an_c3 + resp_an_c4;
        
        
        %a flower image        
        resp_fl_c1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(1))), kb_resp(3));
        
        resp_fl_c2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(2))), kb_resp(4));
        
        resp_fl_c3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(3))), kb_resp(1));
        
        resp_fl_c4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(4))), kb_resp(2));
        
        resp_fl_c(i) = resp_fl_c1 + resp_fl_c2 + resp_fl_c3 + resp_fl_c4;
        
        %a house image        
        resp_ho_c1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(1))), kb_resp(3));
        
        resp_ho_c2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(2))), kb_resp(4));
        
        resp_ho_c3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(3))), kb_resp(1));
        
        resp_ho_c4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(4))), kb_resp(2));
        
        
        resp_ho_c(i) = resp_ho_c1 + resp_ho_c2 + resp_ho_c3 + resp_ho_c4;
        
        %a vehicle image        
        resp_ve_c1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(1))), kb_resp(3));
        
        resp_ve_c2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(2))), kb_resp(4));
        
        resp_ve_c3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(3))), kb_resp(1));
        
        resp_ve_c4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 1 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,7)== Box_resp(4))), kb_resp(2));
        
        resp_ve_c(i) = resp_ve_c1 + resp_ve_c2 + resp_ve_c3 + resp_ve_c4;
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %proportion choosing the cardinal image when the major component is
        %oblique and ....
        
        %an animal image        
        resp_an_o1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(1))), kb_resp(3));
        
        resp_an_o2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(2))), kb_resp(4));
        
        resp_an_o3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(3))), kb_resp(1));
        
        resp_an_o4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(1) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(4))), kb_resp(2));
        
        resp_an_o(i) = resp_an_o1 + resp_an_o2 + resp_an_o3 + resp_an_o4;
        
        
        %a flower image        
        resp_fl_o1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(1))), kb_resp(3));
        
        resp_fl_o2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(2))), kb_resp(4));
        
        resp_fl_o3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(3))), kb_resp(1));
        
        resp_fl_o4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(2) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(4))), kb_resp(2));
        
        resp_fl_o(i) = resp_fl_o1 + resp_fl_o2 + resp_fl_o3 + resp_fl_o4;
        
        %a house image        
        resp_ho_o1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(1))), kb_resp(3));
        
        resp_ho_o2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(2))), kb_resp(4));
        
        resp_ho_o3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(3))), kb_resp(1));
        
        resp_ho_o4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(3) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(4))), kb_resp(2));
        
        resp_ho_o(i) = resp_ho_o1 + resp_ho_o2 + resp_ho_o3 + resp_ho_o4;
        
        %a vehicle image        
        resp_ve_o1 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(1))), kb_resp(3));
        
        resp_ve_o2 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(2))), kb_resp(4));
        
        resp_ve_o3 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(3))), kb_resp(1));
        
        resp_ve_o4 = arrayfun(@(y)length(resp(resp(:,9)==y & ...
            resp(:,2)== 2 & resp(:,3)== m_c_cat(4) & resp(:,5)== CO_R ...
            & resp(:,8)== Box_resp(4))), kb_resp(2));
        
        resp_ve_o(i) = resp_ve_o1 + resp_ve_o2 + resp_ve_o3 + resp_ve_o4;
        
        
                
    end
    
    
    resp_all_c = resp_an_c + resp_fl_c + resp_ho_c + resp_ve_c;
    resp_all_o = resp_an_o + resp_an_o + resp_an_o + resp_an_o;
    
    %%%%%%%%%%%% analyse all the responses %%%%%%%%%%%%%%%%%%%%
    resp_all = resp_all_c + resp_all_o;
    
    mat_resp_all(:,1) = LR_list(:);
    mat_resp_all(:,2) = resp_all(:);
    mat_resp_all(:,3) = 64*10;
    
    
    %psychometric function presets
    options = struct;
    options.sigmoidName = 'norm';
    options.expType = 'YesNo';       
    options.fixedPars = [NaN; NaN; NaN; NaN; NaN];
    
    
    %%%%
    optionsC = struct;
    optionsC.sigmoidName = 'norm';
    optionsC.expType = 'YesNo';       
    optionsC.fixedPars = [0; NaN; NaN; NaN; NaN];
    
    %%%
    optionsB = struct;
    optionsB.sigmoidName = 'norm';
    optionsB.expType = 'YesNo';
    
    
    result_all = psignifit(mat_resp_all, options);
    result_allC = psignifit(mat_resp_all, optionsC);
    
    T(1,1) = result_all.Fit(1); S(1,1) = result_all.Fit(2);
    SC(1,1) = result_allC.Fit(2); L(1,1) = result_all.Fit(3);
    G(1,1) = result_all.Fit(4);
    
    LL_all = NLLpsignifit(mat_resp_all, optionsB, result_all.Fit);
    LL_allC = NLLpsignifit(mat_resp_all, optionsB, result_allC.Fit);
    
    pval(1,1) = 1 - cdf('ChiSquare', 2 * ((-LL_allC) - (-LL_all)), 1);
    [CI_L(1,1), CI_U(1,1)] = NonPBootPsignPALMix(mat_resp_all, options, T(1,1), 95);
    
    
    %plot psyhometric fits
    plotOptions = struct;
    plotOptions.xLabel = 'Stimulus contrast (rms)';
    plotOptions.yLabel = 'Prop. choosing cardinal image';
    plotOptions.CIthresh = true;
    
    figure(1);
    plotPsych(result_all, plotOptions); title('all data'); ylim([0 1]);
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%% split analyses (major_comp == cardinal) %%%%%%%%%%
    mat_resp_anc(:,1) = LR_list(:); mat_resp_anc(:,2) = resp_an_c;
    mat_resp_anc(:,3) = 8;
    
    mat_resp_flc(:,1) = LR_list(:); mat_resp_flc(:,2) = resp_fl_c;
    mat_resp_flc(:,3) = 8;
    
    mat_resp_hoc(:,1) = LR_list(:); mat_resp_hoc(:,2) = resp_ho_c;
    mat_resp_hoc(:,3) = 8;
    
    mat_resp_vec(:,1) = LR_list(:); mat_resp_vec(:,2) = resp_ve_c;
    mat_resp_vec(:,3) = 8;
    
    
    result_anc = psignifit(mat_resp_anc, options);
    result_ancC = psignifit(mat_resp_anc, optionsC);   
    T(2,1) = result_anc.Fit(1); S(2,1) = result_anc.Fit(2);
    SC(2,1) = result_ancC.Fit(2); L(2,1) = result_anc.Fit(3);
    G(2,1) = result_anc.Fit(4);
    LL_anc = NLLpsignifit(mat_resp_anc, optionsB, result_anc.Fit);
    LL_ancC = NLLpsignifit(mat_resp_anc, optionsB, result_ancC.Fit);    
    pval(2,1) = 1 - cdf('ChiSquare', 2 * ((-LL_ancC) - (-LL_anc)), 1);
    [CI_L(2,1), CI_U(2,1)] = NonPBootPsignPALMix(mat_resp_anc, options, T(2,1), 95);
    
    
    result_flc = psignifit(mat_resp_flc, options);
    result_flcC = psignifit(mat_resp_flc, optionsC);    
    T(3,1) = result_flc.Fit(1); S(3,1) = result_flc.Fit(2);
    SC(3,1) = result_flcC.Fit(2); L(3,1) = result_flc.Fit(3);
    G(3,1) = result_flc.Fit(4);
    LL_flc = NLLpsignifit(mat_resp_flc, optionsB, result_flc.Fit);
    LL_flcC = NLLpsignifit(mat_resp_flc, optionsB, result_flcC.Fit);    
    pval(3,1) = 1 - cdf('ChiSquare', 2 * ((-LL_flcC) - (-LL_flc)), 1);
    [CI_L(3,1), CI_U(3,1)] = NonPBootPsignPALMix(mat_resp_flc, options, T(3,1), 95);
    
    
    result_hoc = psignifit(mat_resp_hoc, options);
    result_hocC = psignifit(mat_resp_hoc, optionsC);    
    T(4,1) = result_hoc.Fit(1); S(4,1) = result_hoc.Fit(2);
    SC(4,1) = result_hocC.Fit(2); L(4,1) = result_hoc.Fit(3);
    G(4,1) = result_hoc.Fit(4);
    LL_hoc = NLLpsignifit(mat_resp_hoc, optionsB, result_hoc.Fit);
    LL_hocC = NLLpsignifit(mat_resp_hoc, optionsB, result_hocC.Fit);    
    pval(4,1) = 1 - cdf('ChiSquare', 2 * ((-LL_hocC) - (-LL_hoc)), 1);
    [CI_L(4,1), CI_U(4,1)] = NonPBootPsignPALMix(mat_resp_hoc, options, T(4,1), 95);
    
    
    result_vec = psignifit(mat_resp_vec, options);
    result_vecC = psignifit(mat_resp_vec, optionsC);    
    T(5,1) = result_vec.Fit(1); S(5,1) = result_vec.Fit(2);
    SC(5,1) = result_vecC.Fit(2); L(5,1) = result_vec.Fit(3);
    G(5,1) = result_vec.Fit(4);
    LL_vec = NLLpsignifit(mat_resp_vec, optionsB, result_vec.Fit);
    LL_vecC = NLLpsignifit(mat_resp_vec, optionsB, result_vecC.Fit);    
    pval(5,1) = 1 - cdf('ChiSquare', 2 * ((-LL_vecC) - (-LL_vec)), 1);
    [CI_L(5,1), CI_U(5,1)] = NonPBootPsignPALMix(mat_resp_vec, options, T(5,1), 95);
    
    
    
    figure(2);
    subplot(241)
    plotPsych(result_anc, plotOptions); title('Animal'); ylim([0 1]);
    subplot(242)
    plotPsych(result_flc, plotOptions); title('Flower'); ylim([0 1]);
    subplot(243)
    plotPsych(result_hoc, plotOptions); title('House'); ylim([0 1]);
    subplot(244)
    plotPsych(result_vec, plotOptions); title('Vehicle'); ylim([0 1]);
    
    
    
    %%%%%%%%% split analyses (major_comp == oblique) %%%%%%%%%%
    mat_resp_ano(:,1) = LR_list(:); mat_resp_ano(:,2) = resp_an_o;
    mat_resp_ano(:,3) = 8;
    
    mat_resp_flo(:,1) = LR_list(:); mat_resp_flo(:,2) = resp_fl_o;
    mat_resp_flo(:,3) = 8;
    
    mat_resp_hoo(:,1) = LR_list(:); mat_resp_hoo(:,2) = resp_ho_o;
    mat_resp_hoo(:,3) = 8;
    
    mat_resp_veo(:,1) = LR_list(:); mat_resp_veo(:,2) = resp_ve_o;
    mat_resp_veo(:,3) = 8;
    
    
    result_ano = psignifit(mat_resp_ano, options);
    result_anoC = psignifit(mat_resp_ano, optionsC);    
    T(6,1) = result_ano.Fit(1); S(6,1) = result_ano.Fit(2);
    SC(6,1) = result_anoC.Fit(2); L(6,1) = result_ano.Fit(3);
    G(6,1) = result_ano.Fit(4);
    
    LL_ano = NLLpsignifit(mat_resp_ano, optionsB, result_ano.Fit);
    LL_anoC = NLLpsignifit(mat_resp_ano, optionsB, result_anoC.Fit);    
    pval(6,1) = 1 - cdf('ChiSquare', 2 * ((-LL_anoC) - (-LL_ano)), 1);
    [CI_L(6,1), CI_U(6,1)] = NonPBootPsignPALMix(mat_resp_ano, options, T(6,1), 95);
    
    
    result_flo = psignifit(mat_resp_flo, options);
    result_floC = psignifit(mat_resp_flo, optionsC);    
    T(7,1) = result_flo.Fit(1); S(7,1) = result_flo.Fit(2);
    SC(7,1) = result_floC.Fit(2); L(7,1) = result_flo.Fit(3);
    G(7,1) = result_flo.Fit(4);
    
    LL_flo = NLLpsignifit(mat_resp_flo, optionsB, result_flo.Fit);
    LL_floC = NLLpsignifit(mat_resp_flo, optionsB, result_floC.Fit);    
    pval(7,1) = 1 - cdf('ChiSquare', 2 * ((-LL_floC) - (-LL_flo)), 1);
    [CI_L(7,1), CI_U(7,1)] = NonPBootPsignPALMix(mat_resp_flo, options, T(7,1), 95);
    
    
    result_hoo = psignifit(mat_resp_hoo, options);
    result_hooC = psignifit(mat_resp_hoo, optionsC);    
    T(8,1) = result_hoo.Fit(1); S(8,1) = result_hoo.Fit(2);
    SC(8,1) = result_hooC.Fit(2); L(8,1) = result_hoo.Fit(3);
    G(8,1) = result_hoo.Fit(4);
    
    LL_hoo = NLLpsignifit(mat_resp_hoo, optionsB, result_hoo.Fit);
    LL_hooC = NLLpsignifit(mat_resp_hoo, optionsB, result_hooC.Fit);    
    pval(8,1) = 1 - cdf('ChiSquare', 2 * ((-LL_hooC) - (-LL_hoo)), 1);
    [CI_L(8,1), CI_U(8,1)] = NonPBootPsignPALMix(mat_resp_hoo, options, T(8,1), 95);
    
    
    
    result_veo = psignifit(mat_resp_veo, options);
    result_veoC = psignifit(mat_resp_veo, optionsC);    
    T(9,1) = result_veo.Fit(1); S(9,1) = result_veo.Fit(2);
    SC(9,1) = result_veoC.Fit(2); L(9,1) = result_veo.Fit(3);
    G(9,1) = result_veo.Fit(4);
    
    LL_veo = NLLpsignifit(mat_resp_veo, optionsB, result_veo.Fit);
    LL_veoC = NLLpsignifit(mat_resp_veo, optionsB, result_veoC.Fit);    
    pval(9,1) = 1 - cdf('ChiSquare', 2 * ((-LL_veoC) - (-LL_veo)), 1);
    [CI_L(9,1), CI_U(9,1)] = NonPBootPsignPALMix(mat_resp_veo, options, T(9,1), 95);
    
    
    figure(2);
    subplot(245)
    plotPsych(result_ano, plotOptions); title('Animal'); ylim([0 1]);
    subplot(246)
    plotPsych(result_flo, plotOptions); title('Flower'); ylim([0 1]);
    subplot(247)
    plotPsych(result_hoo, plotOptions); title('House'); ylim([0 1]);
    subplot(248)
    plotPsych(result_veo, plotOptions); title('Vehicle'); ylim([0 1]);
    
    
    %%%%%%%%% categorical biases
    mat_resp_an(:,1) = ratio_en(:); 
    mat_resp_an(:,2) = mat_resp_anc(:,2) + (8 - flipud(mat_resp_ano(:,2)));
    mat_resp_an(:,3) = 16;
    
    mat_resp_fl(:,1) = ratio_en(:); 
    mat_resp_fl(:,2) = mat_resp_flc(:,2) + (8 - flipud(mat_resp_flo(:,2)));
    mat_resp_fl(:,3) = 16;
    
    mat_resp_ho(:,1) = ratio_en(:); 
    mat_resp_ho(:,2) = mat_resp_hoc(:,2) + (8 - flipud(mat_resp_hoo(:,2)));
    mat_resp_ho(:,3) = 16;
    
    mat_resp_ve(:,1) = ratio_en(:); 
    mat_resp_ve(:,2) = mat_resp_vec(:,2) + (8 - flipud(mat_resp_veo(:,2)));
    mat_resp_ve(:,3) = 16;
    
    
    result_an = psignifit(mat_resp_an, options);
    result_anC = psignifit(mat_resp_an, optionsC);    
    T(10,1) = result_an.Fit(1); S(10,1) = result_an.Fit(2);
    SC(10,1) = result_anC.Fit(2); L(10,1) = result_an.Fit(3);
    G(10,1) = result_an.Fit(4);
    LL_an = NLLpsignifit(mat_resp_an, optionsB, result_an.Fit);
    LL_anC = NLLpsignifit(mat_resp_an, optionsB, result_anC.Fit);    
    pval(10,1) = 1 - cdf('ChiSquare', 2 * ((-LL_anC) - (-LL_an)), 1);
    [CI_L(10,1), CI_U(10,1)] = NonPBootPsignPALMix(mat_resp_an, options, T(10,1), 95);
    
    
    result_fl = psignifit(mat_resp_fl, options);
    result_flC = psignifit(mat_resp_fl, optionsC);    
    T(11,1) = result_fl.Fit(1); S(11,1) = result_fl.Fit(2);
    SC(11,1) = result_flC.Fit(2); L(11,1) = result_fl.Fit(3);
    G(11,1) = result_fl.Fit(4);
    LL_fl = NLLpsignifit(mat_resp_fl, optionsB, result_fl.Fit);
    LL_flC = NLLpsignifit(mat_resp_fl, optionsB, result_flC.Fit);    
    pval(11,1) = 1 - cdf('ChiSquare', 2 * ((-LL_flC) - (-LL_fl)), 1);
    [CI_L(11,1), CI_U(11,1)] = NonPBootPsignPALMix(mat_resp_fl, options, T(11,1), 95);
    
    
    result_ho = psignifit(mat_resp_ho, options);
    result_hoC = psignifit(mat_resp_ho, optionsC);    
    T(12,1) = result_ho.Fit(1); S(12,1) = result_ho.Fit(2);
    SC(12,1) = result_hoC.Fit(2); L(12,1) = result_ho.Fit(3);
    G(12,1) = result_ho.Fit(4);
    LL_ho = NLLpsignifit(mat_resp_ho, optionsB, result_ho.Fit);
    LL_hoC = NLLpsignifit(mat_resp_ho, optionsB, result_hoC.Fit);    
    pval(12,1) = 1 - cdf('ChiSquare', 2 * ((-LL_hoC) - (-LL_ho)), 1);
    [CI_L(12,1), CI_U(12,1)] = NonPBootPsignPALMix(mat_resp_ho, options, T(12,1), 95);
    
    
    result_ve = psignifit(mat_resp_ve, options);
    result_veC = psignifit(mat_resp_ve, optionsC);    
    T(13,1) = result_ve.Fit(1); S(13,1) = result_ve.Fit(2);
    SC(13,1) = result_veC.Fit(2); L(13,1) = result_ve.Fit(3);
    G(13,1) = result_ve.Fit(4);
    LL_ve = NLLpsignifit(mat_resp_ve, optionsB, result_ve.Fit);
    LL_veC = NLLpsignifit(mat_resp_ve, optionsB, result_veC.Fit);    
    pval(13,1) = 1 - cdf('ChiSquare', 2 * ((-LL_veC) - (-LL_ve)), 1);
    [CI_L(13,1), CI_U(13,1)] = NonPBootPsignPALMix(mat_resp_ve, options, T(13,1), 95);
    
    
    figure(3);
    subplot(221)
    plotPsych(result_an, plotOptions); title('Animal'); ylim([0 1]);
    subplot(222)
    plotPsych(result_fl, plotOptions); title('Flower'); ylim([0 1]);
    subplot(223)
    plotPsych(result_ho, plotOptions); title('House'); ylim([0 1]);
    subplot(224)
    plotPsych(result_ve, plotOptions); title('Vehicle'); ylim([0 1]);
    
    
    P_est = [T, S, SC, L, G, pval, CI_L, CI_U];
    
    warning on;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    










