function SC = biasPresets(num)



major_comps = repmat([1 2], 1,2); %1 - caridnal, 2 - oblique
cats = 1:4;
LR_list = 0;
R_list = exp(LR_list);
num_trials = numel(major_comps) * numel(cats) * numel(R_list);


trial_combs = allcomb(major_comps, cats, R_list);
SC(:,1) = ones(numel(trial_combs(:,1)),1).*num;
SC(:,2:4) = trial_combs;


        
        