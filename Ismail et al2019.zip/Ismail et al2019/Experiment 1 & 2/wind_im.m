function im_w = wind_im(im)

%Author: AM
%created: 09 / 11 / 2016

%This function outputs a windowed image; specify the window (w) below

%for the original hybrid experiment we used a power of 0.5
%for the revision experiment 

w = circCosine(im, 0.5);
mu = weightedMean(im, w);
im_new = (im - mu) ./ mu;
im_w = im_new .* w;