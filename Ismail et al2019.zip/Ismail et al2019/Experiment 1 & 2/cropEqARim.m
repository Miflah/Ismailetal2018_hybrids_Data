function out = cropEqARim(im)

%crop images to equal aspect ratio

            h = size(im,1);
            w = size(im,2);
            
            if h > w
                st = randi(2,1);
                if st == 1
                    im = im(1:w,:);
                elseif st == 2
                    im = im(end-w+1:end,:);
                end             
                
                
            elseif w > h
                st = randi(2,1);
                if st == 1
                    im = im(:,1:h);
                elseif st == 2
                    im = im(:,end-h+1:end);
                end
            end
            
            out = im;