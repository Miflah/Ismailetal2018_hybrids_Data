function out = scaleRange(input, OldMin, OldMax, NewMin, NewMax)

OldRange = (OldMax - OldMin);

NewRange = (NewMax - NewMin);

out = (((input - OldMin) * NewRange) / OldRange) + NewMin;

