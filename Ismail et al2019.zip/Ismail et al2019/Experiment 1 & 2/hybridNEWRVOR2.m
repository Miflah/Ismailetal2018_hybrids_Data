function hybridNEWRVOR2(name, gam, stim_dur, run)

%hybrid expeirment for the the JEP revision
%this include 4 image categories (in Set-C and Set-I)
%small animal, large animal, small (man-made) object, large (man-made) object
%images will also be orientation filtered


%in each trial and in each block

close all;
sca;


    tic
    
    subjectName = name;

    dateString = datestr(now);
    dateString(dateString == ' ') =  '_';
    dateString(dateString == '-') =  '_';
    dateString(dateString == ':') =  '_';
    
    study_n = 'hybridNEWRVOR2';
    
    file_name = [subjectName '_' study_n '_' num2str(stim_dur) '_' ...
        num2str(run) '_' dateString];
    
%seed random number generator
    rng('Shuffle');
    
%screen setup
    res = [1200 800]; %resolution of the screen (change if necessary at screen stup below)
    PsychImaging('PrepareConfiguration');
    AssertOpenGL;
    screenid = max(Screen('Screens'));
    
    if gam == 1
        [w, rect] = BexInitWrapper;
        gray = 0;
        inc = 0;
        
    else
        
        [w, rect] = PsychImaging('OpenWindow', screenid, 127.5, [400,50,450+1024,50+768], 32,...
            2,[], [], kPsychNeed32BPCFloat); %screen setup
        
        white = WhiteIndex(screenid);
        black = BlackIndex(screenid);
        gray = (black + white) / 2;
        inc = white - gray;
    end
        
        ifi = Screen('GetFlipInterval', w); %refresh rate of the screen
        MaxPriority(w);
        
        %range of pixel intensities to display
        Screen('ColorRange', w, 255);
%         
% %screen coordinates
    W = rect(RectRight);
    H = rect(RectBottom);
    
% Keyboard setup
    responseKeys = {'1','2','4','5'};

    KbName('UnifyKeyNames');
    KbCheckList = [KbName('space'),KbName('ESCAPE')];
    for i = 1:length(responseKeys)
        KbCheckList = [KbName(responseKeys{i}),KbCheckList];
    end
    RestrictKeysForKbCheck(KbCheckList);
    HideCursor; 
    
    
    %timing / stimulus presets
    
    fix_dur = round(1 / ifi);
    mask_dur = stim_dur * 2;
    waitF = 1;
    
    cat_names = {'AnimalsLarge', 'AnimalsSmall', 'InanimateLarge',...
        'InanimateSmall'};
    
    or_band = 20;
    
    
    %manipulating variables
    num_repeats = 5;
    anim_cats = repmat([1 2],1,num_repeats);
    ina_cats = [3 4];
    anim_filt = [0 45];
    
           
    LR_list = [-3.66,-2.20,-1.39,-0.41,-0.20,0,0.20,0.41,1.39,2.20,3.66];
    R_list = exp(LR_list);    
    
    %total number of trials
    num_trials = numel(anim_cats) * numel(ina_cats) * numel(R_list) ...
        * numel(anim_filt);
    
    %combination of levels of each manipulating variable for each trial
    trial_combs = allcomb(anim_cats, ina_cats, R_list, anim_filt); 
    Shuffled_combs = trial_combs(randperm(end),:);
    
    %store image names from each  category for setC
    for i = 1 : numel(cat_names)
        
        cur_cat = cat_names{i};
        
        im_Folder = ['TestStim/AnimInam_BS/NewSet/' cur_cat '/card'];
        im_List=dir(fullfile(im_Folder,['*.' 'png']));
        im_List={im_List(:).name};
        
        for j = 1 : numel(im_List)
            
            AllC_names{j,i} = ['TestStim/AnimInam_BS/NewSet/',...
                cur_cat '/' im_List{j}];
        end
               
    end
    
    %store image names from each  category for setI
    for i = 1 : numel(cat_names)
        
        cur_cat = cat_names{i};
        
        im_Folder = ['TestStim/AnimInam_BS/NewSet/' cur_cat '/obl'];
        im_List=dir(fullfile(im_Folder,['*.' 'png']));
        im_List={im_List(:).name};
        
        for j = 1 : numel(im_List)
            
            AllO_names{j,i} = ['TestStim/AnimInam_BS/NewSet/',...
                cur_cat '/' im_List{j}];
        end
               
    end
    
    
    
    %pick random animate and inanimate image numbers for each trial
    for i = 1 : num_trials
        
        a_num = randi(100,1);
        i_num = randi(100,1);
        
        if i > 1
            while anim_nums(i-1) == a_num
                a_num = randi(100,1);
            end
        end
        
        if i > 1
            while ina_nums(i-1) == i_num
                i_num = randi(100,1);
            end
        end
        
        anim_nums(i) = a_num;
        ina_nums(i) = i_num;
        
    end
        
    Shuffled_combs(:,5) = anim_nums(:);
    Shuffled_combs(:,6) = ina_nums(:);
    
     
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%circular window presets

im_size = 400; %height and width of the window
[xx,yy] = ndgrid((1:im_size)-im_size/2,(1:im_size)-im_size/2); %meshgrid
circ_mask = (xx.^2 + yy.^2) > 150^2; %hard-edged circular window


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%starting the experiment

    Screen('DrawText', w, '1-Animal and 2-Manmade', (W/2-100), (H/2-20), 255);
    Screen('DrawText', w, 'Press any key to begin', (W/2-75), (H/2+20), 255);
    Screen('Flip', w);
    KbStrokeWait;
    
    
%starting fixation
    Screen('BlendFunction', w, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
    Screen('FillOval', w, 255, [W/2-4 H/2-4 W/2+4 H/2+4]);
    vbl = Screen('Flip', w);
    
    for frame = 1: round(1/ifi) -1
        Screen('FillOval', w, 255, [W/2-4 H/2-4 W/2+4 H/2+4]);
        vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%running experimental trials

    data(:,1) = 1 : num_trials;
    data(:,2) = Shuffled_combs(:,1); %carp category
    data(:,3) = Shuffled_combs(:,2); %unc category
    data(:,4) = Shuffled_combs(:,3); %energy ratio
    data(:,5) = Shuffled_combs(:,4); %anim filtering
    data(:,6) = Shuffled_combs(:,5); %carp number
    data(:,7) = Shuffled_combs(:,6); %unc number
    
    
    %additional pad
    pad_lr = ones(300,50);
    pad_td = ones(50,400);
    
    
    c = 1;
    num_out = 0;
    for t = 1 : num_trials
        
        tr_LR = Shuffled_combs(t,3);
        tr_anim_filt = Shuffled_combs(t,4);
                     
        ima_cat = Shuffled_combs(t,1);
        imi_cat = Shuffled_combs(t,2);
        
        ima_num = Shuffled_combs(t,5);
        imi_num = Shuffled_combs(t,6);
        
        
        if tr_anim_filt == 0
            hyb_c = im2double(rgb2gray(imread(AllC_names{ima_num,ima_cat}))); 
            hyb_o = im2double(rgb2gray(imread(AllO_names{imi_num,imi_cat})));
        elseif tr_anim_filt == 45
            hyb_c = im2double(rgb2gray(imread(AllC_names{imi_num,imi_cat}))); 
            hyb_o = im2double(rgb2gray(imread(AllO_names{ima_num,ima_cat})));
        end
        
        hyb_c = wind_im([pad_td;pad_lr,hyb_c,pad_lr;pad_td]);
        hyb_o = wind_im([pad_td;pad_lr,hyb_o,pad_lr;pad_td]);
        
        [~, ult_sum, hyb] = createHybrid(hyb_c, hyb_o, tr_LR);
              
        
        data(t,8) = ult_sum;
        
        back_mask = PhaseRandomize(hyb);
        
        back_mask(back_mask >1) = 1;
        back_mask(back_mask <-1) = -1;
        
        
        %save clipping details
        outbound = hyb(hyb < -1 | hyb > 1);
        if numel(outbound) > 0
            c = c + 1;
            num_out = c;
        end
        clip_perc(t) = numel(outbound) / (300*300);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        
        
        hyb(hyb>1) = 1;
        hyb(hyb<-1) = -1;
        
        tr_stim = texConverter(overlaymask(hyb, circ_mask, 0),...
            gray,inc);
        
        back_stim = texConverter(overlaymask(back_mask, circ_mask, 0),...
            gray,inc);
               
        
        stim_tex = Screen('MakeTexture', w, tr_stim);
        back_tex = Screen('MakeTexture', w, back_stim);
        
        trialRect=Screen('Rect', stim_tex);
        
        
        %%%%%%%%%%%%% TRIAL START %%%%%%%%%%%%%
        
        %show fixation
        for frame = 1 : fix_dur
            
            Screen('FillOval', w, [255 255 255], [W/2-4 H/2-4 W/2+4 H/2+4]);
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        %present the stimulus
        for frame = 1 : stim_dur
            
            Screen('DrawTexture', w, stim_tex, [],...
                CenterRect(trialRect, rect));
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        
        %backward mask
        for frame = 1 : mask_dur
            
            Screen('DrawTexture', w, back_tex, [],...
                CenterRect(trialRect, rect));
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        
        %response
        
        respStart = GetSecs;
        
        while GetSecs > respStart
            
            Screen('DrawText', w, 'RESP', (W/2-25), (H/2-20), 255);
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            
            [keyIsDown, ~, keyCode] = KbCheck;
            if keyIsDown
                pressedKeys = find(keyCode);
                if numel(pressedKeys) > 1
                    pressedKeys = pressedKeys(1);
                end
                
                if keyCode(KbName('ESCAPE')) == 1
                    clear all
                    close all
                    sca
                    return;
                end
                
                data(t,9) = pressedKeys;
                break;
            end
            
        end
        
        Screen('Close', stim_tex); 
        Screen('Close', back_tex);
        
        %giving a break after 201 trials)
        if mod(t, 221) == 0
            Screen('DrawText', w, 'Break time. Press SPACE to continue', (W/2-250), (H/2), 255);
            Screen('Flip',w)
            
            while 1
                [~, ~, keyCode] = KbCheck;
                if keyCode(KbName('space')) == 1;
                    break
                end
            end
        end
        
        
    end
        
        
        
        
      
    
    
Screen(w,'Close');
Screen('Close')
close all;
sca;

    elap_time = toc / 60;
    
    if exist(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',subjectName],'dir') == 7
            save(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',subjectName,...
            '\' file_name '.mat'],'data','fix_dur','num_trials',...
            'or_band','stim_dur','mask_dur','elap_time','LR_list',...
            'num_out','clip_perc')
            
            
    else
            mkdir(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',...
            subjectName]);
            save(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',subjectName,...
            '\' file_name '.mat'],'data','fix_dur','num_trials',...
            'or_band','stim_dur','mask_dur','elap_time','LR_list',...
            'num_out','clip_perc')
            
    end
    
    


return;
end
    
    
    
    
    
    
   