function im_vw = CSFOEF(im)

%Author: AM 
%created: 02/11/2016

%the function takes a 2-D image as the input and outputs the same image
%through a 'window of visibility'. The amplitude spectrum of the image is
%modulated by a 2-D filter - a combination of a CSF (the gain of the filter
%is dependent on the spatial frequency) and a OEF (the gain depends on the
%orientation and spatial frequency)

%The filters and paramter values were obtained 1) directly from Watson and
%Ahumada (2005), Lesmes et al () or by fitting a function to the ModelFest
%data


% if ~ ismatrix(im)
%     
%     im = rgb2gray(im);
%     
% end

% im = im2double(im); %convert to double precision floating points

% im = im - mean2(im); %difference image (with DC = 0)

im_fft = fft2(im); %2-D fourier transform of the image
im_amp = abs(im_fft); %amplitude spectrum
im_phase = angle(im_fft);


%create a meshgrid of the image's size to apply the filter
[vsize, usize] = size(im_fft);
vrad = round(vsize/2);
urad = round(usize/2);
u = -urad : -urad + usize - 1; %handles odd dimensions
v = -vrad : -vrad + vsize - 1;
[U,V] = meshgrid(u,v);



%filter presets (CSF filter)
lambda = 11.404; %wavelength of the peak frequency component (3.5cyc/deg) in pixels

Fmax = size(im_fft,1) / lambda; %peak frequency in fourier space
Gmax = 1; %maximum gain of the filter

k = log10(2); %a constant

beta = 0.8349; %bandwidth of the CSF filter:beta = log10(2 * b), where b is
             %is the bandwidth in octaves
delta = 0.2550; %truncation level at low spatial frequencies             


%filter presets (OEF filter)
dec = Fmax; %the frequency after which sensitivity begins to decline
slope = size(im_fft,1) / 2.93; %slope of linear-log decline


%normalised matrices for spatial frequencies and orientations
sf = sqrt(U.^2 + V.^2) + eps; %matrix of normalised radius from centre 
                              %(spat.freq); +eps to avoid sqrt(0)
t = atan2(-V,U); %matrix of polar angles from centre (orientations)


%CSF filter (log-parabola)
CSF = zeros(size(sf));

for i = 1 : numel(sf)
    CSF(i) = log10(Gmax) - k * ( (log10(sf(i)) - log10(Fmax)) / (beta / 2) ).^2;
    if (sf(i) < Fmax && CSF(i) < log10(Gmax) - delta)
        CSF(i) = log10(Gmax) - delta;
    end
        
    
end

CSF = 10 .^ CSF; %antilog of the CSF filter


%OEF filter (linear-log)
OEF = zeros(size(t));

for i = 1: numel(t)
    OE = 1 - (1 - exp (- ((sf(i) - dec) ./ slope) )) * (sin(2 .* t(i)).^2);
    if sf(i) <= dec
        OEF(i) = 1;
    else
        OEF(i) = OE;
    end
end

combined_F = fftshift( OEF .* CSF);
combined_F(1,1) = 0;

% im_psd = im_amp .^ 2;
% mod_psd = im_psd .* combined_F; %power spectra modulated by window of visibility
% 
% mod_amp = sqrt(mod_psd);
mod_amp = im_amp .* combined_F;
im_vw = ifft2(mod_amp .* exp(sqrt(-1) * (im_phase)));
im_vw = real(im_vw);
















