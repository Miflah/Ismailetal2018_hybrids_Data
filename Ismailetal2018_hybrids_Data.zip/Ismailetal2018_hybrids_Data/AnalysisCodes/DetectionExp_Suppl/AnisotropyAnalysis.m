 function P_est = AnisotropyAnalysis(files)

%Author: AM (created on 29/03/2017)

%'T' -> thresholds (63% of the function)
%'S' -> slope (beta parameter of the log-weibul aka gumbel function)

%%% usage (for data from a single participant) %%%%
% a1 = load('IZ_AnisotropyXVW_3_1_22_Mar_2018_10_26_41.mat');
% a2 = load('IZ_AnisotropyXVW_3_2_22_Mar_2018_10_34_26.mat');
% a3 = load('IZ_AnisotropyXVW_3_3_22_Mar_2018_10_44_50.mat');
% a4 = load('IZ_AnisotropyXVW_3_4_22_Mar_2018_10_52_20.mat');
% P_est = AnisotropyAnalysis({a1,a2,a3,a4});

num_files = length(files);

resp = [];

for i = 1 : num_files
    
    cur_file = files{i};
    resp_m = (cur_file.data);
    resp = [resp ; resp_m];
end


cats = 1:4; %image categories (1-animal,2-flower,3-house,4-vehicle)

en_list = logspace(log10(0.0001), log10(0.01), 11); %Fourier energy values

key_I1 = KbName('1');
key_I2 = KbName('2');


%proportion correct for each image category at each Fourier energy


for i = 1: numel(cats)
    
    cur_cat = cats(i);
    
    
    for j = 1: numel(en_list)
        
        cur_en = en_list(j);
        
        
        resp_I1 = arrayfun(@(y)length(resp(resp(:,6)==y & resp(:,2)== cur_cat ...
            & resp(:,4)==cur_en & resp(:,5)==1)),key_I1);
        
        resp_I2 = arrayfun(@(y)length(resp(resp(:,6)==y & resp(:,2)== cur_cat ...
            & resp(:,4)==cur_en & resp(:,5)==2)),key_I2);
        
        resp_tot(i,j) = resp_I1 + resp_I2;
        
    end
    
end

%animals
mat_resp_an(:,1) = sqrt(en_list(:));
mat_resp_an(:,2) = resp_tot(1,:);
mat_resp_an(:,3) = 20;

%flowers
mat_resp_fl(:,1) = sqrt(en_list(:));
mat_resp_fl(:,2) = resp_tot(2,:);
mat_resp_fl(:,3) = 20;
        
%houses
mat_resp_ho(:,1) = sqrt(en_list(:));
mat_resp_ho(:,2) = resp_tot(3,:);
mat_resp_ho(:,3) = 20;

%vehicles
mat_resp_ve(:,1) = sqrt(en_list(:));
mat_resp_ve(:,2) = resp_tot(4,:);
mat_resp_ve(:,3) = 20;
        

%psychometric function presets (normal)
    options = struct;
    options.sigmoidName = 'weibull';
    options.expType = '2AFC';       
    options.fixedPars = [NaN; NaN; NaN; 0.5; NaN];
    
    
    %psychomteric function presets (bootstrap)
    optionsB = struct;
    optionsB.sigmoidName = 'weibull';
    optionsB.expType = '2AFC';
    optionsB.fixedPars = [NaN; NaN; NaN; 0.5; NaN];
    
    
    result_an = psignifit(mat_resp_an, options);
    SP = getStandardParameters(result_an);
    T(1) = SP(1);
    S(1) = SP(2);
%     L(1) = SP(3);
    [CI_L(1), CI_U(1)] = NonPBootPsignPALMix(mat_resp_an, optionsB, T(1), 95);
%     S(1) = result_an.Fit(2);    
    
    result_fl = psignifit(mat_resp_fl, options);
    SP = getStandardParameters(result_fl);
    T(2) = SP(1);
    S(2) = SP(2);
%     L(2) = SP(3);
    [CI_L(2), CI_U(2)] = NonPBootPsignPALMix(mat_resp_fl, optionsB, T(2), 95);
%     S(2) = result_fl.Fit(2);
    
    result_ho = psignifit(mat_resp_ho, options);
    SP = getStandardParameters(result_ho);
    T(3) = SP(1);
    S(3) = SP(2);
%     L(3) = SP(3);
    [CI_L(3), CI_U(3)] = NonPBootPsignPALMix(mat_resp_ho, optionsB, T(3), 95);
%     S(3) = result_ho.Fit(2);
    
    result_ve = psignifit(mat_resp_ve, options);
    SP = getStandardParameters(result_ve);
    T(4) = SP(1);
    S(4) = SP(2);
%     L(4) = SP(3);
    [CI_L(4), CI_U(4)] = NonPBootPsignPALMix(mat_resp_ve, optionsB, T(4), 95);
%     S(4) = result_ve.Fit(2);
    
    
%plot psyhometric fits
    plotOptions = struct;
    plotOptions.xLabel = 'Stimulus energy';
    plotOptions.yLabel = 'Prop. Detection';
    plotOptions.CIthresh = true;
    

    figure(1);
    subplot(2,2,1);
    plotPsych(result_an, plotOptions); title(['Animal = ' num2str(T(1))]); ylim([0.4 1]);
    subplot(2,2,2);
    plotPsych(result_fl, plotOptions); title(['Flower = ' num2str(T(2))]); ylim([0.4 1]);
    subplot(2,2,3);
    plotPsych(result_ho, plotOptions); title(['House = ' num2str(T(3))]); ylim([0.4 1]);
    subplot(2,2,4);
    plotPsych(result_ve, plotOptions); title(['Vehicle = ' num2str(T(4))]); ylim([0.4 1]);
    
    P_est = [T', S', CI_L',CI_U'];
    
    
    
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

