function CI = BiasAccCI(bootSample, MLEStat, Iterations, CIRange)

%the function computes bias corrected and accelerated confidence intervals
%for a bootstrapped sample
%codes are based on Geoff Boynton's online scripts
%(http://www.mbfys.ru.nl/~robvdw/DGCN22/PRACTICUM_2011/LABS_2011/ALTERNATIVE_LABS/)

%Author: AM (created on 26/01/2017)

%Inputs
    % 'bootSample' -> distribution of bootstrapped paramter estimates
    % 'MLEStat' -> maximum likelihood estimate of the parameter with the
    % original dataset
    % 'Iterations' -> number of boostrap iterations carreid out
    % 'CIRange' -> range of CI to be computed (default = 68.27)
    
%Outputs
    % 'CI' -> Bias corrected confidence intervals

%outputs almost identical to Josh's mathematica script (differences in the 3rd decimal point)    

%pre-requisities (function handle)

%Calculates the inverse of the unit normal cumulative density function. 
%It returns the z-score corresponding to p, the area under the curve to the
%left in the unit normal distribution.  (See also Matlab's erfinv function)
inverseNormalCDF = @(x) sqrt(2)*erfinv(2*x-1);

z0 = inverseNormalCDF(sum(bootSample < MLEStat) / Iterations);

a = 0;

if nargin < 4
    
    CIRange = 68.27;
    
end

zLo = inverseNormalCDF((1-CIRange/100)/2);
zHi = inverseNormalCDF((1+CIRange/100)/2);
zClo = z0 + (z0+zLo)/(1-a*(z0+zLo));
bcaLo = NormalCumulative(zClo,0,1);
zChi = z0 + (z0+zHi)/(1-a*(z0+zHi));
bcaHi = NormalCumulative(zChi,0,1);
CI(1) = prctile(bootSample,100*bcaLo);
CI(2) = prctile(bootSample,100*bcaHi);


    



