function [CI_L, CI_U] = NonPBootPsignPALMix(data_mat, options, est, CI_range)

%Author: AM(created on 17/02/2017)

%the function simulates proportion of responses for each stimulus level
%using a method from the PALAMEDES toolbox. Simulated values are then used
%to fit psychometric functions using the PsignifitFast options (4X speed).
%The distribution of threhsold estimates obtained are then bias corrected
%and accelerated using Geoff Boynton's method to give confidence intervals
%for the (Non-parametric) bootstrapped distribution. 

%Inputs
%'data_mat' -> n x 3 matrix of StimLevels, NumPos, OutOfNum
%'options' -> options struct for fitting PF
%'est' -> maximum likeliood estimate of threshold
%'CI_range' -> Confidence interval range (default 95%)

if nargin < 4
    
    CI_range = 95;
end
    


Num_boot = 1000;

boot_sample = zeros(1,Num_boot);

    for i = 1: Num_boot
        
        NumPos = PAL_PF_SimulateObserverNonParametric(data_mat(:,1), ...
            data_mat(:,2), data_mat(:,3));
        
        data_new(:,1) = data_mat(:,1);
        data_new(:,2) = NumPos(:);
        data_new(:,3) = data_mat(:,3);
        
        result_new = psignifitFast(data_new, options);
        boot_sample(i) = result_new.Fit(1);
        
    end
    
CI = BiasAccCI(boot_sample, est, Num_boot, CI_range);

CI_L = CI(1);
CI_U = CI(2);


end
        
        


