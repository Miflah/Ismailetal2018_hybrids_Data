function PS_Image = PhaseRandomize(img)

%load image
if isa(img,'uint8')
    img = im2double(rgb2gray(img));
elseif isa(img,'double')
    img = img;
else
    img = im2double(img);
end

rng('shuffle');
imgsize = size(img); %image dimension

% lvl = 180;
% up_L1 = lvl * (pi/180);
% randPhase = rand(imgsize(1),imgsize(2));
% 
% randPhase1 = (up_L1 - (-up_L1)).* randPhase + (-up_L1);
% imgCR = ContrastReduce(img,0.5);

randPhase1 = angle(fft2(rand(imgsize(1), imgsize(2))));

%fourier transforming the original image
F = fft2(img);
Amp = abs(F); %amplitude
imgPhase = angle(F); %phase

%generating new phase values by adding random phase offsets to the original
%phase values
newPhase1 = imgPhase + randPhase1;


%phase scrambled images
PS_Image = ifft2(Amp.*exp(sqrt(-1)*newPhase1),'symmetric');

PS_Image = real(PS_Image);

% RMSOr = sqrt((sum(img(:).^2)-(((sum(img(:))).^2)/numel(img)))/numel(img))
% RMS_PS = sqrt((sum(PS_Image(:).^2)-(((sum(PS_Image(:))).^2)/numel(PS_Image)))/numel(PS_Image))
% 
% std(img(:))
% std(PS_Image(:))
% 
% new = mat2gray(PS_Image);
% RMS_new = sqrt((sum(new(:).^2)-(((sum(new(:))).^2)/numel(new)))/numel(new))
