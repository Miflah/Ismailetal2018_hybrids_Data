function out = overlaymask (image,mask,clr)


% color = [0.5 0.5 0.5];
if numel(clr) == 1
    color = [clr clr clr];
    mask = (mask ~= 0);
    in_new = image;
    color_new = double(color);
    in_new(mask)   = color_new(1);

    out = in_new;  
    
    
    
elseif numel(clr) == 3
    color = [clr(1) clr(2) clr(3)];
    mask = (mask ~= 0);
    
    in_uint8 = uint8(image);
    color_uint8 = uint8(color);
    
    
   % Input is RGB truecolor.
    out_red   = in_uint8(:,:,1);
    out_green = in_uint8(:,:,2);
    out_blue  = in_uint8(:,:,3);
        
    out_red(mask)   = color_uint8(1);
    out_green(mask) = color_uint8(2);
    out_blue(mask)  = color_uint8(3);
    out = cat(3, out_red, out_green, out_blue);
    
    
end

