function [txt, mc_loc, cc_loc] = RespBox(cat_names, t_m_im, t_c_im)

%Author: AM (created on 22/12/2016)

locs = Shuffle(1:4); %possible response locations

mc_loc = locs(1); %location of major component
cc_loc = locs(2); %location of complementary compoenent
ex1_loc = locs(3); %location of extra1 component (not in the hybrid)
ex2_loc = locs(4); %location of extra2 component (not in the hybrid)

extra_cats = Shuffle(setdiff(1:4, [t_m_im, t_c_im])); %not in the hybrid

t_e1_im = extra_cats(1); %category of extra1 component
t_e2_im = extra_cats(2); %category of extra2 component


%texts for each response location (box)
txt{mc_loc} = cat_names{t_m_im}; 
txt{cc_loc} = cat_names{t_c_im};
txt{ex1_loc} = cat_names{t_e1_im};
txt{ex2_loc} = cat_names{t_e2_im};