function out=texConverter(normTex,gray,inc)
% TEXCONVERTER(normTex,gray,inc) 
%
% texConverter(normTex,0,0)=norm2rgbFrm(normTex).
% If gray ~= 0 or inc ~= 0, then texConverter(normTex,0,0) = gray+inc*normTex.

if gray==0 && inc==0
    out=norm2rgbFrm(normTex);
else
    out=gray+inc*normTex;
end


