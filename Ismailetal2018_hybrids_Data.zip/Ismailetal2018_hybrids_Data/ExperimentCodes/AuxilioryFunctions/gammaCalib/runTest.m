function runTest


    PsychDefaultSetup(2);
    HideCursor;


%define Gamma on the red, green and blue guns
    R_gamma = 2.3495;
    G_gamma = 2.3756;
    B_gamma = 2.3250;
    
% Create LUT
    xx = [0:1/255:1]';
    LUT_table = [xx.^(1/R_gamma) xx.^(1/G_gamma) xx.^(1/B_gamma)];  
    
    PsychImaging('PrepareConfiguration');
    AssertOpenGL;
    
    white=WhiteIndex(2);
    black=BlackIndex(2);
    gray=(white+black)/2;
    inc=white-gray;
    


[w, wRect] = PsychImaging('OpenWindow', 2, gray, [], 32, 2); %screen setup

%screen coordinates
    W = wRect(RectRight);
    H = wRect(RectBottom);

% Define the displaying color range:
    Screen('ColorRange', w, 1, 0);

% Load the LUTs
    Screen('LoadNormalizedGammaTable', w, LUT_table); % load the gamma corrected LUT

Screen(w,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

Screen('FillRect',w, 0.5);
Screen('Flip', w);

im = double(imread('im15.png'));
standard = im - mean2(im);
standard = RMSmatch(standard, [0.5 0.25]);
standard(standard < 0) =0;
% standard = scaleRange(standard,-1,1,0,255);
% standard = overlay;



standardTex=Screen('MakeTexture',w,standard);
Screen('DrawTexture', w, standardTex, [], [W/2-150 H/2-150 W/2+150 H/2+150]);
Screen('Flip', w);
WaitSecs(5);

Screen('Close',standardTex);
Screen('CloseAll')
ShowCursor;
fclose('all');


