function [w, wRect]=BexInitWrapper
%BexINITWRAPPER sets the global variable BEXINIT = true and returns the
%appropriate [windowPtr,rect].

global BEXINIT BETA KAPPA GAMMA
BEXINIT = true;   
%See gammaFit.nb for details.
BETA=0;
KAPPA=0.0052605744428308185;
GAMMA=2.3717555462336324;
% Open a double buffered fullscreen window and draw a gray background 
% and front and back buffers.  On OS X we 
screens=Screen('Screens');
screenNumber=max(screens);
[w, wRect]=PsychImaging('OpenWindow',screenNumber, 0,[],32,...
            2,[], [], kPsychNeed32BPCFloat);

x=norm2rgbFrm(0);
% x(1)
% x(2)
% x(3)
Screen('FillRect',w, [x(1) x(2) x(3)]);
Screen('Flip', w);
