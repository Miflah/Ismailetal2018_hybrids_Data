function convertedTex=showConvertedTex(bex)
%SHOWCONVERTEDTEX(bex) uses the bex box if and only if bex==1.

% check for opengl compatability
AssertOpenGL;

HideCursor;

if bex==1
    [w, wRect]=BexInitWrapper;
    gray=0;
    inc=0;
%     Screen('BlendFunction', w, 'GL_ONE', 'GL_ZERO');

else
    [w, wRect]=Screen('OpenWindow',2, 0,[],32,2);
%     Screen(w,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    Screen('BlendFunction', w, 'GL_ONE', 'GL_ZERO');

    % Find the color values which correspond to white and black.  Though on OS
    % X we currently only support true color and thus, for scalar color
    % arguments,
    % black is always 0 and white 255, this rule is not true on other platforms will
    % not remain true on OS X after we add other color depth modes.  
    white=WhiteIndex(0);
    black=BlackIndex(0);
    gray=(white+black)/2;
    inc=white-gray;
    Screen('FillRect',w, gray);
    Screen('Flip', w);
end

%     Screen('ColorRange', w, 255, 0);

%     im = im2double(imread('im15.png'));
%     standard = im - mean2(im);
%     standard = RMSmatch(standard, [0 0.05]);


% standard = GaborImage([400 400],0,0,[45 45],pi/2);% A fixation spot.
% standard = repmat(linspace(-1,1,300),300,1);

%special input
rows = 300;
row_sp = linspace(-0.9,1,rows);
for i = 1: rows
row_max = row_sp(i);
standard(i,:) = linspace(-1,row_max,rows);
end



convertedTex=texConverter(standard,gray,inc);
ndims(convertedTex)


standardTex=Screen('MakeTexture',w,convertedTex);
standardRect=Screen('Rect', standardTex);
Screen('DrawTexture', w, standardTex, [], CenterRect(standardRect, wRect));
Screen('Flip', w);

WaitSecs(10);
% On some computers, a mouse-click is necessary to return the screen to normal.
Screen('Close',standardTex);
Screen('CloseAll');
ShowCursor;
fclose('all');



%%%%%verify conversion
% rows = 300;
% row_sp = linspace(-0.9,1,rows);
% for i = 1: rows
% row_max = row_sp(i);
% norm(i,:) = linspace(-1,row_max,rows);
% end
% KAPPA=0.005490136334353958;
% GAMMA = 2.038021594181943;
% xxx8bit=min(max(((norm+1).^(1/GAMMA))/KAPPA,0),2^8-1);
% one=floor(xxx8bit);
% two=floor((xxx8bit - one)*(255 - one));
% three = floor(  ( (xxx8bit - one) * (255 - one) - floor( (xxx8bit - one) * ...
% (255 - one ) ) ) * (  255 - one - floor( (xxx8bit - one) * (255 - one)  )  ));
% rgbFrm(:,:,1)=uint8(one+two+three);
% rgbFrm(:,:,2)=uint8(one+two);
% rgbFrm(:,:,3)=uint8(one);
% imshow(rgbFrm)
% figure;
% subplot(141);imshow(rgbFrm);
% subplot(142);imshow(rgbFrm(:,:,1));
% subplot(143);imshow(rgbFrm(:,:,2));
% subplot(144);imshow(rgbFrm(:,:,3));






