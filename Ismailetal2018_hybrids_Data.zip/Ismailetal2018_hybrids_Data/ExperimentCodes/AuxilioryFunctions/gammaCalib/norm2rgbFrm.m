function rgbFrm = norm2rgbFrm(norm)
%
% Convert a normalized m-by-n matrix, into a gamma-corrected 8-bit RGB matrix. 
% norm has dimensions m-by-n. Each entry in norm is a double between -1 and 1.     
%
% History:
% 
% 2007-01-18  jas     wrote it. 

% 2016-08-12 AM fixed bugs in lines 23-24

global BEXINIT BETA KAPPA GAMMA
if BEXINIT ~= true
    return
end

% KAPPA=0.0052605744428308185;
% GAMMA=2.3717555462336324;

xxx8bit=min(max(((norm+1).^(1/GAMMA))/KAPPA,0),2^8-1);

one=floor(xxx8bit);
two=floor((xxx8bit - one)*sqrt(32)); %JAS changed this (09/09/2016)
three=floor((xxx8bit - two)*31); %JAS changed this (09/09/2016)


rgbFrm(:,:,1)=uint8(one+two+three);
rgbFrm(:,:,2)=uint8(one+two);
rgbFrm(:,:,3)=uint8(one);