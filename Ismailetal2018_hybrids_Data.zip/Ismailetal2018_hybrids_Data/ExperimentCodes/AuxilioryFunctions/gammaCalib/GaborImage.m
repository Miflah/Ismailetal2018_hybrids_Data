function m = GaborImage(sz,angle,freq,spread,phase)
%GABORIMAGE 2-D Gabor image.
%   GABORIMAGE(sz,angle,freq,spread,phase) computes a 2-D image of a Gabor
%   function.
%   sz is [horizPix vertPix].
%   angle in degrees off vertical.
%   freq in cycles/pixel.
%   spread is [horizSigma vertSigma].
%   phase in radians; 0 is sin phase.

[x,y]=meshgrid(-floor(sz(1)/2):floor((sz(1)-1)/2),-floor(sz(2)/2):floor((sz(2)-1)/2));
rads=angle*pi/180; 
a=cos(rads)*freq*2*pi;
b=sin(rads)*freq*2*pi;
m=exp(-((x/(sqrt(2)*spread(1))).^2)-((y/(sqrt(2)*spread(2))).^2)).*sin(a*x+b*y+phase);