%first do these lines
w=Screen('OpenWindow', 2,0,[],32,2);
Screen('FillRect', w, [0, 0, 0, 255]);
%then do these *if* using a mid-gray background
	white=WhiteIndex(1);
	black=BlackIndex(1);
	gray=(white+black)/2;
	inc=white-gray;
    	Screen('FillRect',w, gray);
    	Screen('Flip', w);
%then these two with various values for...
%Screen('FillRect', w, [255, 255, 255, 255],[350,250,650,550]);
Screen('FillRect', w, [1, 1, 1]*255,[350,250,650,550]);
Screen('Flip',w);