function [x, y] = polartocart(distance, angle)

%Author: AM

%Arguments:      'distance' -> distance of the desired coordinate in pixels
%               from the centre

%               'angle'    -> angle of the desired coordinate from the
%               centre; angle values start at the positive side of the
%               x-axis and go counter-clockwise: input in degrees

x = round(distance * cos(deg2rad (angle) )); 
%values rounded to nearest integer (pixels don't exist in decimals :p

y = round(distance * sin(deg2rad (angle) ));