function f = psqfiltorth(u, v, r0, s, t0, w)
   % PSQFILT makes a 2D filter
   %   Vectorized for u,v.
   %
   %   u,v are Fourier coordinates
   %   r0 is peak frequency
   %   s  is half-width of frequency resolution (octaves) 
   %   t0 is peak orientation (radians)
   %   w  is orientation concentration
   
   
   % lognormal radial filter, or unity if s==inf
   % radial distance + eps, to avoid problems at origin (basically avoid
   % taking log of 0)
   r = sqrt(u.^2 + v.^2) + eps;
      
   if ~isinf(s)
       radial = exp(-log(r./r0).^2 / ((s./2).^2 * log(2)));
       %ideal lowpass filter : uncomment if necessary
%        maxR = size(r,1)/2;
%        H = double(r <= maxR);
%        radial = radial .* H;
   else
       radial = ones(size(r));
   end


   %wrapped gaussian orientation filter (Steve Dakin) 
   if ~isinf(w)
       t=atan2(-v,u);
       aDiff = atan(sin(t-(pi+t0))./cos(t-(pi+t0)));
       AngTemp = exp(-(aDiff.^2)./(2*(w^2)));
   else
       AngTemp = ones(size(r));
   end
   
   
   %orthogonal gaussian profile (same Steve's code as above)
   
   if ~isinf(w)
       t0New = t0 + (pi/2);
       aDiff1 = atan(sin(t-(pi+t0New))./cos(t-(pi+t0New)));
       AngTemp1 = exp(-(aDiff1.^2)./(2*(w^2)));
   else
       AngTemp1 = ones(size(r));
   end
   
   gauss_comb = AngTemp + AngTemp1;
       
        
   
   
   
   %rectangular filter (triangular in fourier domain)
   bandBT = 30 * (pi/180); %angular width of the filter
   bowtie1 = abs(cos((t-t0))) > cos(bandBT);
   bowtie2 = abs(cos((t-t0New))) > cos(bandBT);
   
   bowtie = bowtie1 + bowtie2;
   
   
  
%     wrapped gaussian (Pete Bex)
%     if ~isinf(w)
%         angDist = atan2(-v,u);
%         sintheta = sin(angDist);
%         costheta = cos(angDist);
%         ds = sintheta * cos(t0) - costheta * sin(t0);
%         dc = costheta * cos(t0) + sintheta * sin(t0);
%         dtheta = abs(atan2(ds,dc));
%         AngTemp = exp((-dtheta.^2) / (2 * w^2));
%         
%         t0=t0+pi; 
%         ds = sintheta * cos(t0) - costheta * sin(t0);
%         dc = costheta * cos(t0) + sintheta * sin(t0);
%         dtheta = abs(atan2(ds,dc));
%         AngTemp = AngTemp+exp((-dtheta.^2) / (2 * w^2)); 
%     else
%         AngTemp = ones(size(r));
%     end


            

   % Combined filter
   f = radial .* gauss_comb;
   
%    figure;surf(u,v,f,'LineStyle','none');colormap jet
%       figure;imshow(f);colormap jet
   
   f = fftshift(f); %need to fftshift to do fourier transform
   f(1,1) = 0; %remove the dc term

      
end
