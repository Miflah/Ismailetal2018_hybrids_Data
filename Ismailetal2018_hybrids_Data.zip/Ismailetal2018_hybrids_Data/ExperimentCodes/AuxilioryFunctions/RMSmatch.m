function out = RMSmatch(input, target)


if size(target,1) > 1 && size(target,2)
    
    mu_targ = mean2(target);
    
    mu_inp = mean2(input);
    
    tau_TI = std2(target) / std2(input);
    
elseif size(target,1) == 1 && size(target,2) == 2
    
    mu_targ = target(1);
    
    mu_inp = mean2(input);
    
    std_targ = target(2);
    
    tau_TI = std_targ / std2(input);
else
    error('incorrect number of input dimensions')
    
end

out = mu_targ + tau_TI * (input - mu_inp);