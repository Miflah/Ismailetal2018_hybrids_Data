function out = circCosine(img, pow, rad)

%Author: AM (created on 16 / 09 / 2016)

%the function creates a 2-D circularly symmetric cosine window for an image
%of any size (but dimensions should be an even number)

% height = size(img, 1);
% width = size(img, 2);

[height, width] = size(img);
hrad = round(height /2);
wrad = round(width / 2);

x = -wrad : -wrad + width - 1;
y = -hrad : -hrad + height - 1;

if nargin < 3
    rad = floor( min([height width]) / 2);
end

[xx, yy] = meshgrid(x, y);

r = sqrt(xx.^2 + yy.^2) + eps;

cos_w = (cos (  (pi / rad) * r));
wind = 0.5 + 0.5 * cos_w;
wind(r > rad) = 0;

out = wind .^ pow;


 