function [ult_ER, ult_sum, hyb] = createHybrid(card_im, obl_im, des_ER)


% card_im = card_im - mean2(card_im);
% obl_im = obl_im - mean2(obl_im);


or_band = 20;

% card_amp = abs(fft2(card_im));
% obl_amp = abs(fft2(obl_im));


[~,card_amp] = ORfiltAmp(card_im, 10, inf, 0, or_band, 0); %amplitude spectrum of cardinally filtered component
[~,obl_amp] = ORfiltAmp(obl_im, 10, inf, 45, or_band, 0); %amplitude spectrum of intercardinally filtered component

% card_amp = abs(fft2(card));
% obl_amp = abs(fft2(obl));
ve_card = WindVisib(card_amp); %visible energy of cardinally filtered AS
ve_obl = WindVisib(obl_amp); %visible energy of intercardinally filtered AS

orig_ER = ve_card / ve_obl; %visible enery ratio between the two

    %adjusting the ratio of one component to produce equal energy (1:1) ratio

    if ve_card > ve_obl %if energy of cardinal component is greater
    
        mod_obl_amp = obl_amp * sqrt(orig_ER);
        mod_card_amp = card_amp;
        
    elseif ve_card < ve_obl %if energy of intercardinal is greater
        
        mod_card_amp = card_amp / sqrt(orig_ER);
        mod_obl_amp = obl_amp;
        
    elseif ve_card == ve_obl %if they are equal
        mod_card_amp = card_amp;
        mod_obl_amp = obl_amp;       
        
    end
    
    
    %to verify
%     new_ve_card = WindVisib(mod_card_amp);
%     new_ve_obl = WindVisib(mod_obl_amp);
%     new_ER = new_ve_card / new_ve_obl
    

    des_sum = 2.6665e+08/2; %desired sum of visible energy of the two components
    
    if des_ER < 1 %if we need a ratio where cardinal should be less visible
    
        mod_card_amp = mod_card_amp * sqrt(des_ER); %reduce energy in cardinal 
        ult_ve_card = WindVisib(mod_card_amp);
        ult_ve_obl = WindVisib(mod_obl_amp);
        
        %once the desired energy ratio is obtained (scale denominator and
        %numerator of ratio to sum to 'des_sum'
        
        sc_fact = des_sum / (ult_ve_card+ult_ve_obl); 
        mod_card_amp = mod_card_amp .* sqrt(sc_fact);
        mod_obl_amp = mod_obl_amp .* sqrt(sc_fact);      
        
    
    elseif des_ER > 1 %if we need a ratio where cardinal should be more visible
        
        mod_obl_amp = mod_obl_amp / sqrt(des_ER); %reduce energy in intercardinal
        ult_ve_card = WindVisib(mod_card_amp);
        ult_ve_obl = WindVisib(mod_obl_amp);
        sc_fact = des_sum / (ult_ve_card+ult_ve_obl);
        mod_card_amp = mod_card_amp .* sqrt(sc_fact);
        mod_obl_amp = mod_obl_amp .* sqrt(sc_fact);
        
    else
        ult_ve_card = WindVisib(mod_card_amp);
        ult_ve_obl = WindVisib(mod_obl_amp);
        sc_fact = des_sum / (ult_ve_card+ult_ve_obl);
        mod_card_amp = mod_card_amp .* sqrt(sc_fact);
        mod_obl_amp = mod_obl_amp .* sqrt(sc_fact);
    end

    ult_ve_card = WindVisib(mod_card_amp);
    ult_ve_obl = WindVisib(mod_obl_amp);

    ult_ER = ult_ve_card / ult_ve_obl; %verify that new ratio is == 'des_ER'
    
    
    ult_sum = ult_ve_card + ult_ve_obl; %verify that sum of cardinal energy and
    %intercardinal energy is == 'des_sum'
    
    
    %obtain phase spectrum of unfiltered images used for cardinal and
    %intercardinal components
    card_phase = angle(fft2(card_im));
    obl_phase = angle(fft2(obl_im));
    
    
    %inverse Fourier transform
    new_card = real(ifft2(mod_card_amp .* exp(sqrt(-1) * (card_phase))));
    new_obl = real(ifft2(mod_obl_amp .* exp(sqrt(-1) * (obl_phase))));
    
    hyb = new_card + new_obl;
    %the hybrid should ideally have values in the range -1 to 1
    
    