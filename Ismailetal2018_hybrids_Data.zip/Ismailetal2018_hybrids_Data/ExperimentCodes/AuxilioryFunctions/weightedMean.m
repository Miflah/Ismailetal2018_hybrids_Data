function mu = weightedMean(im, w)

%based on van der Schaaf and van Hateran (1996).

%'im' is a 2D double precision image in the range 0 to 1
%'w' is a 2D (weighing) window of same size as 'im', also ranging from 0 to 1

mu = sum(sum(im .* w)) / sum(sum(w));