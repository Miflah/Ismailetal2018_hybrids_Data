function [F,res] = filteringorth(im, lambda, sigma, theta, omega, pad)

% im is the input image.
% lambda is the wavelength in pixels for the peak spatial frequency.The
% wavelength can be a minimum of 2 pixels (but will be aliased), so prefer
% a minimum of 3 or above
% sigma is the half width (specify in octaves) for the lognormal spatial frequency filter.
% theta is the peak orientation (specify in degrees).
% omega is the halfwidth (1 SD) for the gaussian orientation filter (specify in
% degrees).
%pad is the fraction of height or width at each edge to be padded



% im = im - mean(im(:)); %substract the mean from the image (makes no difference anyways)

[height,width] = size(im);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% peak orientation (radians)
theta = theta * (pi/180); %theta in raidans

% orientation concentration : converted to radians here
omega = omega * (pi/180);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Padding
% top/bottom and left/right zero blocks
tbzeros = zeros(pad*height, (1+2*pad)*width);
lrzeros = zeros(height, pad*width);

%the intensity of the pad can be changed to the mean inensity of the image.
%Uncomment this if neccessary
% pad_val = mean(im(:));
% tbzeros = tbzeros + pad_val;
% lrzeros = lrzeros + pad_val;


% zero-padded image
imgpad = [tbzeros; 
          lrzeros, im, lrzeros;
          tbzeros];

% image transform (not fftshifted)
G = fft2(imgpad);

% padded fft size
[vsize, usize] = size(G);

% Fourier coordinates
% u = linspace(-usize/2, usize/2-1, usize); %does not handle odd dimensions
% v = linspace(-vsize/2, vsize/2-1, vsize); %does not handle odd dimensions

vrad = round(vsize/2);
urad = round(usize/2);
u = -urad : -urad + usize - 1; %handles odd dimensions
v = -vrad : -vrad + vsize - 1;

[U,V] = meshgrid(u,v);

% filter
w = sqrt(cos(theta)^2 * usize^2 + sin(theta)^2 * vsize^2);
% f = @(u,v) psqfilt(u,v, w/lambda, sigma, theta, omega);
% F = f(U,V);

f = psqfiltorth(U,V, w/lambda, sigma, theta, omega);
F = f;

% filtered image
tmp = real(ifft2(G .* F));


% unpad image and filter
x0 = pad * width;
y0 = pad * height;
tmp = tmp(1+y0:y0+height, 1+x0:x0+width);

% final image
res = tmp;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plotting the filtered image and its fourier spectrum
% new = mat2gray(res);
% four = fftshift(fft2(new));
% pow = log(abs(four)+1);
% pow = mat2gray(pow);
% 
% figure;
% subplot(121);imshow(new);colormap gray;freezeColors;title('filtered image')
% subplot(122);imshow(pow);colormap default;colorbar;title('fourier spectrum')
