function detectCat2(name, gam, stim_dur, run)


close all;
sca;


    tic
    
    subjectName = name;

    dateString = datestr(now);
    dateString(dateString == ' ') =  '_';
    dateString(dateString == '-') =  '_';
    dateString(dateString == ':') =  '_';
    
    study_n = 'AnisotropyXVW';
    
    file_name = [subjectName '_' study_n '_' num2str(stim_dur) '_' ...
        num2str(run) '_' dateString];
    
%seed random number generator
    rng('Shuffle');
    
%screen setup
%     res = [1200 800]; %resolution of the screen (change if necessary at screen stup below)
    PsychImaging('PrepareConfiguration');
    AssertOpenGL;
    screenid = max(Screen('Screens'));
    
    if gam == 1
        [w, rect] = BexInitWrapper;
        gray = 0;
        inc = 0;
        
    else
        
        [w, rect] = PsychImaging('OpenWindow', screenid, 0, [], 32,...
            2,[], [], kPsychNeed32BPCFloat); %screen setup
        
        white = WhiteIndex(screenid);
        black = BlackIndex(screenid);
        gray = (black + white) / 2;
        inc = white - gray;
    end
        
        ifi = Screen('GetFlipInterval', w); %refresh rate of the screen
        MaxPriority(w);
        
        %range of pixel intensities to display
        Screen('ColorRange', w, 255);
        
%screen coordinates
    W = rect(RectRight);
    H = rect(RectBottom);
    
% Keyboard setup
    responseKeys = {'1','2'};

    KbName('UnifyKeyNames');
    KbCheckList = [KbName('space'),KbName('ESCAPE')];
    for i = 1:length(responseKeys)
        KbCheckList = [KbName(responseKeys{i}),KbCheckList];
    end
    RestrictKeysForKbCheck(KbCheckList);
    HideCursor; 
    
    
    %timing / stimulus presets
    
    fix_dur = round(1 / ifi);
    isi = round(0.3 / ifi);
    waitF = 1;
    
   
    %manipulating variables
    repeats = 5;
    cats = repmat(1:4, 1, repeats);
%     en_list = 0.01;
    en_list = logspace(log10(0.0001), log10(0.01), 11);
    
    num_trials = numel(cats) * numel(en_list); 
        
    %combination of levels of each manipulating variable for each trial
    trial_combs = allcomb(cats, en_list); 
    Shuffled_combs = trial_combs(randperm(end),:);
    
    %comment out if you want to verify perfect occurances of each
    %combination
%     int_col = Shuffled_combs(:,[1 2]);
%     [unqrows,~,idx] = unique(int_col,'rows');
%     counts = accumarray(idx(:),1);
%     out = [unqrows counts]



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%load all the target images for each category

        load([name '_imnums.mat'])
        
        if run == 1; subset = 1:55;
        elseif run == 2; subset = 56:110;
        elseif run == 3; subset = 111:165;
        elseif run == 4; subset = 166:220;
        end
            

        an_nums = targ_nums{1}(subset);
        fl_nums = targ_nums{2}(subset);
        ho_nums = targ_nums{3}(subset);
        ve_nums = targ_nums{4}(subset);
        
        an_f_nums = flank_nums{1}(subset);
        fl_f_nums = flank_nums{2}(subset);
        ho_f_nums = flank_nums{3}(subset);
        ve_f_nums = flank_nums{4}(subset);
        
        
        %laod animal target and flank images
        Anim_Folder = 'TestStimuli/Animals';
        Anim_List=dir(fullfile(Anim_Folder,['*.' 'png']));
        Anim_List={Anim_List(:).name};
        
        for i = 1 : repeats * numel(en_list)
            im_name = Anim_List{an_nums(i)}; %targ file name
            im_f_name = Anim_List{an_f_nums(i)}; %flank file name
            
            im = imread(fullfile(Anim_Folder,im_name)); %read targ file
            flank = imread(fullfile(Anim_Folder,im_f_name)); %read flank file
            Anim_images{1,i} = wind_im(im2double(im));
            Anim_flanks{1,i} = wind_im(im2double(flank));
        end
        
                
        %laod flower target and flank images
        Flow_Folder = 'TestStimuli/Flowers';
        Flow_List=dir(fullfile(Flow_Folder,['*.' 'png']));
        Flow_List={Flow_List(:).name};
        
        for i = 1 : repeats * numel(en_list)
            im_name = Flow_List{fl_nums(i)}; %targ file name
            im_f_name = Flow_List{fl_f_nums(i)}; %flank file name
            
            im = imread(fullfile(Flow_Folder,im_name)); %read targ file
            flank = imread(fullfile(Flow_Folder,im_f_name)); %read flank file
            Flow_images{1,i} = wind_im(im2double(im));
            Flow_flanks{1,i} = wind_im(im2double(flank));
        end


        %laod house target and flank images
        Hous_Folder = 'TestStimuli/Houses';
        Hous_List=dir(fullfile(Hous_Folder,['*.' 'png']));
        Hous_List={Hous_List(:).name};
        
        for i = 1 : repeats * numel(en_list)
            im_name = Hous_List{ho_nums(i)}; %targ file name
            im_f_name = Hous_List{ho_f_nums(i)}; %flank file name
            
            im = imread(fullfile(Hous_Folder,im_name)); %read targ file
            flank = imread(fullfile(Hous_Folder,im_f_name)); %read flank file
            Hous_images{1,i} = wind_im(im2double(im));
            Hous_flanks{1,i} = wind_im(im2double(flank));
        end
        
        
        %laod house target and flank images
        Vehic_Folder = 'TestStimuli/Vehicles';
        Vehic_List=dir(fullfile(Vehic_Folder,['*.' 'png']));
        Vehic_List={Vehic_List(:).name};
        
        for i = 1 : repeats * numel(en_list)
            im_name = Vehic_List{ve_nums(i)}; %targ file name
            im_f_name = Vehic_List{ve_f_nums(i)}; %flank file name
            
            im = imread(fullfile(Vehic_Folder,im_name)); %read targ file
            flank = imread(fullfile(Vehic_Folder,im_f_name)); %read flank file
            Vehic_images{1,i} = wind_im(im2double(im));
            Vehic_flanks{1,i} = wind_im(im2double(flank));
        end
        
        
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%circular window presets

im_size = 300; %height and width of the window
[xx,yy] = ndgrid((1:im_size)-im_size/2,(1:im_size)-im_size/2); %meshgrid
circ_mask = (xx.^2 + yy.^2) > (im_size/2)^2; %hard-edged circular window

%1/f noise presets
alpha = 1;
vsize = 300; usize = 300;
vrad = round(vsize/2);
urad = round(usize/2);
u = -urad : -urad + usize - 1; %handles odd dimensions
v = -vrad : -vrad + vsize - 1;
[U,V] = meshgrid(u,v);
r = sqrt(U.^2 + V.^2) + eps;
filter = r .^ (-alpha);
filter = fftshift(filter);
filter(1,1) = 0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%starting the experiment

    Screen('DrawText', w, 'Use keys 1 and 2', (W/2-50), (H/2-20), 255);
    Screen('DrawText', w, 'Press any key to begin', (W/2-75), (H/2), 255);
    Screen('Flip', w);
    KbStrokeWait;
    
    
%starting fixation
    Screen('BlendFunction', w, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
    Screen('FillOval', w, 255, [W/2-4 H/2-4 W/2+4 H/2+4]);
    vbl = Screen('Flip', w);
    
    for frame = 1: round(1/ifi) -1
        Screen('FillOval', w, 255, [W/2-4 H/2-4 W/2+4 H/2+4]);
        vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
    end
    

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%running experimental trials

    data(:,1) = 1 : num_trials;
    data(:,2) = Shuffled_combs(:,1);
    data(:,4) = Shuffled_combs(:,2);
    
    an_ct = 1; fl_ct = 1; ho_ct = 1; ve_ct =1;
    
    
    
    for t = 1 : num_trials
        
        
        trial_cat = Shuffled_combs(t,1);
        trial_en = Shuffled_combs(t,2);
        
        if trial_cat == 1
            trial_im = Anim_images{an_ct}; trial_flank = Anim_flanks{an_ct};
            an_ct = an_ct + 1;
        elseif trial_cat == 2
            trial_im = Flow_images{fl_ct}; trial_flank = Flow_flanks{fl_ct};
            fl_ct = fl_ct + 1;
        elseif trial_cat == 3
            trial_im = Hous_images{ho_ct}; trial_flank = Hous_flanks{ho_ct};
            ho_ct = ho_ct + 1;
        elseif trial_cat == 4
            trial_im = Vehic_images{ve_ct}; trial_flank = Vehic_flanks{ve_ct};
            ve_ct = ve_ct + 1;
        end
        
        
        %creating target stimulus
%         trial_im = CSFOEF(trial_im);
        trial_im = RMSmatch(trial_im, [0 sqrt(trial_en)]);
        
        im_fft = fft2(trial_im);
        im_amp = abs(im_fft);        
                
        im_mask = random('norm', 0, 0.10, [300 300]);
        im_mask = im_mask - mean2(im_mask);
        im_mask_fft = fft2(im_mask);
        
        im_mask = real(ifft2(im_amp.*exp(sqrt(-1) * angle(im_mask_fft)),'symmetric'));        
        im_mask = RMSmatch(im_mask, [0 0.10]);
        
        trial_targ = trial_im + im_mask;
        out_t = numel(trial_targ(trial_targ < -1 | trial_targ > 1));
        pout_t(t) = out_t/(300*300);
        
        trial_targ(trial_targ < -1) = -1;
        trial_targ(trial_targ > 1) = 1;
        
        trial_targ = texConverter(overlaymask(trial_targ, circ_mask, 0),...
            gray,inc);                      
                       
        targ_tex = Screen('MakeTexture', w, trial_targ);
        trialRect=Screen('Rect', targ_tex);
        
        %creating non-target stimulus
%         trial_flank = CSFOEF(trial_flank);
        trial_flank = PhaseRandomize(trial_flank);
        trial_flank = RMSmatch(trial_flank, [0 sqrt(trial_en)]);
        
        flank_fft = fft2(trial_flank);
        flank_amp = abs(flank_fft);
                        
        flank_mask = random('norm', 0, 0.10, [300 300]);
        flank_mask = flank_mask - mean2(flank_mask);
        flank_mask_fft = fft2(flank_mask);
        
        flank_mask = real(ifft2(flank_amp.*exp(sqrt(-1) * angle(flank_mask_fft)),'symmetric'));      
        flank_mask = RMSmatch(flank_mask, [0 0.10]);
        
        trial_nont = trial_flank + flank_mask;
        out_nt = numel(trial_nont(trial_nont < -1 | trial_nont > 1));
        pout_nt(t) = out_nt/(300*300);
        
        trial_nont(trial_nont < -1) = -1;
        trial_nont(trial_nont > 1) = 1;
        
        trial_nont = texConverter(overlaymask(trial_nont, circ_mask, 0),...
            gray,inc);                      
                       
        nont_tex = Screen('MakeTexture', w, trial_nont);
        
        %temporal position of the target in a 2-IFC
        targ_int = randi(2,1);
        data(t,5) = targ_int;
        
%         if targ_int == 1
%             int1_tex = targ_tex;
%             int2_tex = nont_tex;
%         elseif targ_int == 2
%             int1_tex = nont_tex;
%             int2_tex = targ_tex;
%         end
                       
       
            
        
        
        %%%%%%%%%%%%% TRIAL START %%%%%%%%%%%%%
        
        %show fixation
        for frame = 1 : fix_dur
            
            Screen('FillOval', w, [255 255 255], [W/2-4 H/2-4 W/2+4 H/2+4]);
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        
       if targ_int == 1 
            %present the stimulus in interval 1
            for frame = 1 : stim_dur            
                Screen('DrawTexture', w, targ_tex, [],...
                    CenterRect(trialRect, rect));
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end
            for frame = 1 : isi
            
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end       
            %present the stimulus in interval 2
            for frame = 1 : stim_dur
            
                Screen('DrawTexture', w, nont_tex, [],...
                    CenterRect(trialRect, rect));
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end
            for frame = 1 : isi
            
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end
            
       elseif targ_int == 2
           for frame = 1 : stim_dur            
                Screen('DrawTexture', w, nont_tex, [],...
                    CenterRect(trialRect, rect));
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end
            for frame = 1 : isi
            
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end       
            %present the stimulus in interval 2
            for frame = 1 : stim_dur
            
                Screen('DrawTexture', w, targ_tex, [],...
                    CenterRect(trialRect, rect));
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end
            for frame = 1 : isi
            
                vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            end
       end
           
        
       
        
            
        %response
        
        respStart = GetSecs;
        
        while GetSecs > respStart
            
            Screen('DrawText', w, 'RESP', (W/2-25), (H/2-20), 255);
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            
            [keyIsDown, ~, keyCode] = KbCheck;
            if keyIsDown
                pressedKeys = find(keyCode);
                if numel(pressedKeys) > 1
                    pressedKeys = pressedKeys(1);
                end
                
                if keyCode(KbName('ESCAPE')) == 1
                    clear all
                    close all
                    sca
                    return;
                end
                
                data(t,6) = pressedKeys;
                break;
            end
            
        end
        
        Screen('Close', targ_tex); Screen('Close', nont_tex);
%         Screen('Close', int1_tex); Screen('Close', int2_tex);
        
        %giving a break after 201 trials)
        if mod(t, 111) == 0
            Screen('DrawText', w, 'Break time. Press SPACE to continue', (W/2-250), (H/2), 255);
            Screen('Flip',w)
            
            while 1
                [~, ~, keyCode] = KbCheck;
                if keyCode(KbName('space')) == 1;
                    break
                end
            end
        end
        
       
        
        
        
        
        
    end
    
    
    
    
Screen(w,'Close');
Screen('Close')
close all;
sca;


    elap_time = toc / 60;
    
    if exist(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\Anisotropy\',subjectName],'dir') == 7
            save(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\Anisotropy\',subjectName,...
            '\' file_name '.mat'],'data','fix_dur','num_trials',...
            'stim_dur','isi','elap_time')
            
            
    else
            mkdir(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\Anisotropy\',...
            subjectName]);
            save(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\Anisotropy\',subjectName,...
            '\' file_name '.mat'],'data','fix_dur','num_trials',...
            'stim_dur','isi','elap_time')
            
    end
    
    
return;
end       
        
        
        
        
        
        
      