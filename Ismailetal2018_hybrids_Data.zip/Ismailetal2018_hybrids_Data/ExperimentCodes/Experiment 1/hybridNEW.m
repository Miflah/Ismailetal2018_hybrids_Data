function hybridNEW(name, gam, stim_dur, run)


%in each trial and in each block

close all;
sca;


    tic
    
    subjectName = name;

    dateString = datestr(now);
    dateString(dateString == ' ') =  '_';
    dateString(dateString == '-') =  '_';
    dateString(dateString == ':') =  '_';
    
    study_n = 'hybridNEW';
    
    file_name = [subjectName '_' study_n '_' num2str(stim_dur) '_' ...
        num2str(run) '_' dateString];
    
%seed random number generator
    rng('Shuffle');
    
%screen setup
    res = [1200 800]; %resolution of the screen (change if necessary at screen stup below)
    PsychImaging('PrepareConfiguration');
    AssertOpenGL;
    screenid = max(Screen('Screens'));
    
    if gam == 1
        [w, rect] = BexInitWrapper;
        gray = 0;
        inc = 0;
        
    else
        
        [w, rect] = PsychImaging('OpenWindow', screenid, 127.5, [400,50,450+1024,50+768], 32,...
            2,[], [], kPsychNeed32BPCFloat); %screen setup
        
        white = WhiteIndex(screenid);
        black = BlackIndex(screenid);
        gray = (black + white) / 2;
        inc = white - gray;
    end
        
        ifi = Screen('GetFlipInterval', w); %refresh rate of the screen
        MaxPriority(w);
        
        %range of pixel intensities to display
        Screen('ColorRange', w, 255);
%         
% %screen coordinates
    W = rect(RectRight);
    H = rect(RectBottom);
    
% Keyboard setup
    responseKeys = {'1','2','4','5'};

    KbName('UnifyKeyNames');
    KbCheckList = [KbName('space'),KbName('ESCAPE')];
    for i = 1:length(responseKeys)
        KbCheckList = [KbName(responseKeys{i}),KbCheckList];
    end
    RestrictKeysForKbCheck(KbCheckList);
    HideCursor; 
    
    
    %timing / stimulus presets
    
    fix_dur = round(1 / ifi);
    mask_dur = stim_dur * 2;
    waitF = 1;
    
    or_band = 20; %bandwidth of the orientation filter in deg (Std. Dev)
    
    cat_names = {'Animal', 'Flower', 'House', 'Vehicle'};
    
    
    %manipulating variables
    major_comps = repmat([1 2], 1,2); %1 - caridnal, 2 - oblique
    cats = 1:4; %1 - animal, 2 - flower, 3 - house, 4 - vehicle
    
    LR_list = [-3.66,-2.20,-1.39,-0.41,-0.20,0,0.20,0.41,1.39,2.20,3.66];
    R_list = exp(LR_list);    
    
    %total number of trials
    num_trials = numel(major_comps) * numel(cats) * numel(R_list);
    
    %combination of levels of each manipulating variable for each trial
    trial_combs = allcomb(major_comps, cats, R_list); 
    Shuffled_combs = trial_combs(randperm(end),:);
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%load image category of the major component, complimentary component and
%the backward mask in each trial
        for i = 1: num_trials
            trial_major = Shuffled_combs(i,2); %major component
            avail_comp = setdiff(1:4, trial_major); %available complementary components
            trial_comp = avail_comp(randi(3,1)); %complementary component for the trial
            avail_mask = setdiff(1:4, [trial_major, trial_comp]); %available categories for mask
            trial_majors(i) = trial_major; %category of major component
            trial_comps(i) = trial_comp; %category of complementary component
        end     



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
    %load cardinal images from each category
    Anim_Folder = 'TestStim/ChosenTests/card_an';
    Anim_List=dir(fullfile(Anim_Folder,['*.' 'png']));
    Anim_List={Anim_List(:).name};
    for i = 1 : length(Anim_List)
        im_name = Anim_List{i}; %file name
        im = imread(fullfile(Anim_Folder,im_name)); %read file
        AllC_images{1,i} = wind_im(im2double(im)); %apply a Circular cosine window
                                                   %and make a difference image
    end
         
          
    Flow_Folder = 'TestStim/ChosenTests/card_flow';
    Flow_List=dir(fullfile(Flow_Folder,['*.' 'png']));
    Flow_List={Flow_List(:).name};
    for i = 1 : length(Flow_List)
        im_name = Flow_List{i};
        im = imread(fullfile(Flow_Folder,im_name));
        AllC_images{2,i} = wind_im(im2double(im));
    end
            
    
    Hous_Folder = 'TestStim/ChosenTests/card_hous';
    Hous_List=dir(fullfile(Hous_Folder,['*.' 'png']));
    Hous_List={Hous_List(:).name};
    for i = 1 : 100
        im_name = Hous_List{i};
        im = imread(fullfile(Hous_Folder,im_name));
        AllC_images{3,i} = wind_im(im2double(im));
    end
    
    
    Vehic_Folder = 'TestStim/ChosenTests/card_vehic';
    Vehic_List=dir(fullfile(Vehic_Folder,['*.' 'png']));
    Vehic_List={Vehic_List(:).name};
    for i = 1 : 100
        im_name = Vehic_List{i};
        im = imread(fullfile(Vehic_Folder,im_name));
        AllC_images{4,i} = wind_im(im2double(im));
    end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %load oblique images from each category
    Anim_Folder = 'TestStim/ChosenTests/obl_an';
    Anim_List=dir(fullfile(Anim_Folder,['*.' 'png']));
    Anim_List={Anim_List(:).name};
    for i = 1 : length(Anim_List)
        im_name = Anim_List{i};
        im = imread(fullfile(Anim_Folder,im_name));
        AllO_images{1,i} = wind_im(im2double(im));
    end
         
          
    Flow_Folder = 'TestStim/ChosenTests/obl_flow';
    Flow_List=dir(fullfile(Flow_Folder,['*.' 'png']));
    Flow_List={Flow_List(:).name};
    for i = 1 : length(Flow_List)
        im_name = Flow_List{i};
        im = imread(fullfile(Flow_Folder,im_name));
        AllO_images{2,i} = wind_im(im2double(im));
    end
            
    
    Hous_Folder = 'TestStim/ChosenTests/obl_hous';
    Hous_List=dir(fullfile(Hous_Folder,['*.' 'png']));
    Hous_List={Hous_List(:).name};
    for i = 1 : 100
        im_name = Hous_List{i};
        im = imread(fullfile(Hous_Folder,im_name));
        AllO_images{3,i} = wind_im(im2double(im));
    end
    
    
    Vehic_Folder = 'TestStim/ChosenTests/obl_vehic';
    Vehic_List=dir(fullfile(Vehic_Folder,['*.' 'png']));
    Vehic_List={Vehic_List(:).name};
    for i = 1 : 100
        im_name = Vehic_List{i};
        im = imread(fullfile(Vehic_Folder,im_name));
        AllO_images{4,i} = wind_im(im2double(im));
    end
    
   
    
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%circular window presets

im_size = 300; %height and width of the window
[xx,yy] = ndgrid((1:im_size)-im_size/2,(1:im_size)-im_size/2); %meshgrid
circ_mask = (xx.^2 + yy.^2) > (im_size/2)^2; %hard-edged circular window

%response oval presets
hw = 60; %half-width oval box
ts = 48; %adjustment for start coordinate of text (horizontal axis only)
[TL_x, TL_y] = polartocart(175, 225); %centre coordinate of TopLeft oval
[TR_x, TR_y] = polartocart(175, 315); %centre coordinate of TopRight oval
[BL_x, BL_y] = polartocart(175, 135); %centre coordinate of BottomLeft oval
[BR_x, BR_y] = polartocart(175, 45); %centre coordinate of BottomRight oval

%specifying coordinates of the oval's (ie: box surrounding the oval's)
%borders along the horizontal and vertical axes, with reference to the
%centre of the screen
Oval_pos = [W/2 + TL_x - hw, H/2 + TL_y - hw, W/2 + TL_x + hw, H/2 + TL_y + hw;
           W/2 + TR_x - hw, H/2 + TR_y - hw, W/2 + TR_x + hw, H/2 + TR_y + hw;
           W/2 + BL_x - hw, H/2 + BL_y - hw, W/2 + BL_x + hw, H/2 + BL_y + hw;
           W/2 + BR_x - hw, H/2 + BR_y - hw, W/2 + BR_x + hw, H/2 + BR_y + hw]';
       
%horizontal and vertical screen coordinates for the text start position       
txt_TL_pos = [W/2 + TL_x - ts, H/2 + TL_y - 10];       
txt_TR_pos = [W/2 + TR_x - ts, H/2 + TR_y - 10];
txt_BL_pos = [W/2 + BL_x - ts, H/2 + BL_y - 10];
txt_BR_pos = [W/2 + BR_x - ts, H/2 + BR_y - 10];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%starting the experiment

    Screen('DrawText', w, 'Use keys 1, 2, 4 and 5', (W/2-100), (H/2-20), 255);
    Screen('DrawText', w, 'Press any key to begin', (W/2-75), (H/2), 255);
    Screen('Flip', w);
    KbStrokeWait;
    
    
%starting fixation
    Screen('BlendFunction', w, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
    Screen('FillOval', w, 255, [W/2-4 H/2-4 W/2+4 H/2+4]);
    vbl = Screen('Flip', w);
    
    for frame = 1: round(1/ifi) -1
        Screen('FillOval', w, 255, [W/2-4 H/2-4 W/2+4 H/2+4]);
        vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%running experimental trials

    data(:,1) = 1 : num_trials;
    data(:,2) = Shuffled_combs(:,1);
    data(:,3) = trial_majors(:);
    data(:,4) = trial_comps(:);
    
    c = 1;
    for t = 1 : num_trials
        

        t_mc = Shuffled_combs(t,1); %major component of the trial
        
        t_m_im = trial_majors(t); %category of the trial's major component
        t_c_im = trial_comps(t); %category of the trial's complementary component
        
        c_no = randi(100,1); %image number of the cardinal component
        o_no = randi(100,1); %image number of the intercardinal component
        data(t,10) = c_no;
        data(t,11) = o_no;
        
        if t_mc == 1           
            
            card_im = AllC_images{t_m_im, c_no}; %cardinal component
            obl_im = AllO_images{t_c_im, o_no}; %oblique component
            
        elseif t_mc == 2
            
            card_im = AllC_images{t_c_im, c_no};
            obl_im = AllO_images{t_m_im, o_no};
            
        end
        
        des_ER = Shuffled_combs(t,3);
        data(t,5) = des_ER;
        
        [ult_ER, ult_sum, hyb] = createHybrid(card_im, obl_im, des_ER);
        
        PS_mask = PhaseRandomize(hyb);      
        
        
        data(t,12) = ult_ER;
        data(t,13) = ult_sum;
        outbound = hyb(hyb < -1 | hyb > 1);
        if numel(outbound) > 0
            c = c + 1;
            num_out = c;
        end
        clip_perc(t) = numel(outbound) / (300*300);
        
        %clipping overflowing intensities of the hybrid and the mask
        hyb(hyb < -1) = -1;
        hyb(hyb > 1) = 1;
        
        PS_mask(PS_mask < -1) = -1;
        PS_mask(PS_mask > 1) = 1;
        
        
        
        
        
        trial_im = texConverter(overlaymask(hyb, circ_mask, 0),...
            gray,inc); %convert hybrid texture to display through attenuator
                       %after applying the hard-edged circular window
        trial_tex = Screen('MakeTexture', w, trial_im);
        trialRect=Screen('Rect', trial_tex);
        
        trial_mask = texConverter(overlaymask(PS_mask, circ_mask, 0),...
            gray,inc);
        mask_tex = Screen('MakeTexture', w, trial_mask);
        
        
        %trial response texts
        [txt, mc_loc, cc_loc] = RespBox(cat_names, t_m_im, t_c_im);
        
        
        data(t,7) = mc_loc;
        data(t,8) = cc_loc;
        
        All_texts{t} = txt;
        
        
        %%%%%%%%%%%%% TRIAL START %%%%%%%%%%%%%
        
        %show fixation
        for frame = 1 : fix_dur
            
            Screen('FillOval', w, [255 255 255], [W/2-4 H/2-4 W/2+4 H/2+4]);
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        %present the stimulus
        for frame = 1 : stim_dur
            
            Screen('DrawTexture', w, trial_tex, [],...
                CenterRect(trialRect, rect));
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        
        %backward mask
        for frame = 1 : mask_dur
            
            Screen('DrawTexture', w, mask_tex, [],...
                CenterRect(trialRect, rect));
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
        end
        
        
        %response
        
        respStart = GetSecs;
        
        while GetSecs > respStart
            
            Screen('FillOval', w, 180, Oval_pos); 
            Screen('DrawText', w, txt{1}, txt_TL_pos(1), txt_TL_pos(2), 0);
            Screen('DrawText', w, txt{2}, txt_TR_pos(1), txt_TR_pos(2), 0);
            Screen('DrawText', w, txt{3}, txt_BL_pos(1), txt_BL_pos(2), 0);
            Screen('DrawText', w, txt{4}, txt_BR_pos(1), txt_BR_pos(2), 0);
            vbl = Screen('Flip', w, vbl + (waitF - 0.5) * ifi);
            
            [keyIsDown, ~, keyCode] = KbCheck;
            if keyIsDown
                pressedKeys = find(keyCode);
                if numel(pressedKeys) > 1
                    pressedKeys = pressedKeys(1);
                end
                
                if keyCode(KbName('ESCAPE')) == 1
                    clear all
                    close all
                    sca
                    return;
                end
                
                data(t,9) = pressedKeys;
                break;
            end
            
        end
        
        Screen('Close', trial_tex);
        Screen('Close', mask_tex);
        
        %giving a break after 201 trials)
        if mod(t, 91) == 0
            Screen('DrawText', w, 'Break time. Press SPACE to continue', (W/2-250), (H/2), 255);
            Screen('Flip',w)
            
            while 1
                [~, ~, keyCode] = KbCheck;
                if keyCode(KbName('space')) == 1;
                    break
                end
            end
        end
        
        
        
        
        
        
    end
    
    
Screen(w,'Close');
Screen('Close')
close all;
sca;

    elap_time = toc / 60;
    
    if exist(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',subjectName],'dir') == 7
            save(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',subjectName,...
            '\' file_name '.mat'],'data','fix_dur','num_trials',...
            'or_band','stim_dur','mask_dur','elap_time','LR_list','All_texts',...
            'num_out','clip_perc')
            
            
    else
            mkdir(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',...
            subjectName]);
            save(['C:\Users\Isabel_Lab\Documents\MATLAB\Miflah_Experiments\HybridNEW\',subjectName,...
            '\' file_name '.mat'],'data','fix_dur','num_trials',...
            'or_band','stim_dur','mask_dur','elap_time','LR_list','All_texts',...
            'num_out','clip_perc')
            
    end
    
    


return;
end
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    